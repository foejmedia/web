import CardGrid from '@/components/blocks/CardGrid';
import ExploreNext from '@/components/blocks/ExploreNext';
import QuoteBlock from '@/components/blocks/QuoteBlock';
import SectionHead from '@/components/blocks/SectionHead';
import Statement from '@/components/blocks/Statement';
import ClientsStrip from '@/components/sections/ClientsStrip';
import JourneySection from '@/components/sections/JourneySection';
import StatsSection from '@/components/sections/StatsSection';
import WhySection from '@/components/sections/WhySection';
import SiteShell from '@/components/site/SiteShell';
import { valueIcons } from '@/lib/data';
import { InnerHero, PageCta, pageMetadata, resolvePage, staticParams } from '@/lib/pageKit';
import { href } from '@/lib/routes';

export const generateStaticParams = staticParams;
export const generateMetadata = pageMetadata('about', (t) => t.pages.about.hero);

export default async function AboutPage(props: { params: Promise<{ lang: string }> }) {
  const { lang, t } = await resolvePage(props);
  const p = t.pages.about;

  return (
    <SiteShell lang={lang}>
      <InnerHero lang={lang} slug="about" hero={p.hero}>
        <a className="button" href={href(lang, 'services')}>{t.hero.cta} <span>{t.arrow}</span></a>
        <a className="hero-secondary" href={href(lang, 'contact')}>{t.hero.talk} <span>{t.arrow}</span></a>
      </InnerHero>

      <Statement eyebrow={p.statement.eyebrow} text={p.statement.text} p={p.statement.p} image="/assets/photos/engineers.jpg" />

      <section className="section band-light">
        <SectionHead eyebrow={p.mvv.eyebrow} h2a={p.mvv.h2a} h2Em={p.mvv.h2Em} />
        <CardGrid items={p.mvv.items} columns={3} numbered />
      </section>

      <QuoteBlock
        eyebrow={p.leadership}
        quote={t.about.quote}
        body={t.about.body2}
        name={t.about.chairmanName}
        role={t.about.chairmanTitle}
        image="/assets/photos/vision-desert.jpg"
      />

      <section className="section band-dark">
        <SectionHead eyebrow={p.values.eyebrow} h2a={p.values.h2a} h2Em={p.values.h2Em} />
        <CardGrid items={p.values.items} icons={valueIcons} tone="dark" columns={3} />
      </section>

      <JourneySection t={t} />
      <StatsSection t={t} />
      <WhySection t={t} />
      <ClientsStrip t={t} />
      <ExploreNext lang={lang} slugs={['services', 'qhse', 'vision-2030']} />
      <PageCta lang={lang} />
    </SiteShell>
  );
}
