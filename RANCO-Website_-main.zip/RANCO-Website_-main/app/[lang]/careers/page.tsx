import CardGrid from '@/components/blocks/CardGrid';
import CtaBanner from '@/components/blocks/CtaBanner';
import ExploreNext from '@/components/blocks/ExploreNext';
import ProcessSteps from '@/components/blocks/ProcessSteps';
import SectionHead from '@/components/blocks/SectionHead';
import Statement from '@/components/blocks/Statement';
import SiteShell from '@/components/site/SiteShell';
import { valueIcons, whyIcons } from '@/lib/data';
import { InnerHero, pageMetadata, resolvePage, staticParams } from '@/lib/pageKit';

export const generateStaticParams = staticParams;
export const generateMetadata = pageMetadata('careers', (t) => t.pages.careers.hero);

const benefitIcons = [valueIcons[2], valueIcons[4], valueIcons[0], valueIcons[5]];

export default async function CareersPage(props: { params: Promise<{ lang: string }> }) {
  const { lang, t } = await resolvePage(props);
  const p = t.pages.careers;
  const c = t.careers;
  const mail = `mailto:info@ranco.com.sa?subject=${encodeURIComponent(c.mailSubject)}`;

  return (
    <SiteShell lang={lang}>
      <InnerHero lang={lang} slug="careers" hero={p.hero}>
        <a className="button" href={mail}>{p.apply} <span>{t.arrow}</span></a>
        <a className="hero-secondary" href="#teams">{p.areas.eyebrow} <span>↓</span></a>
      </InnerHero>

      <Statement eyebrow={c.eyebrow} text={`${c.h2a} ${c.h2Em}`} p={c.p} image="/assets/photos/team.jpg" />

      <section className="section band-light">
        <SectionHead eyebrow={p.benefits.eyebrow} h2a={p.benefits.h2a} h2Em={p.benefits.h2Em} breakTitle={false} />
        <CardGrid items={p.benefits.items} icons={benefitIcons} columns={4} />
      </section>

      <section className="section band-dark" id="teams">
        <SectionHead eyebrow={p.areas.eyebrow} h2a={p.areas.h2a} h2Em={p.areas.h2Em} />
        <CardGrid items={p.areas.items} icons={whyIcons} tone="dark" columns={3} numbered />
      </section>

      <ProcessSteps {...p.process} />
      <ExploreNext lang={lang} slugs={['about', 'qhse', 'vision-2030']} />
      <CtaBanner
        eyebrow={c.eyebrow}
        h2a={`${c.h2a} `}
        h2Em={c.h2Em}
        p={c.small}
        arrow={t.arrow}
        image="/assets/photos/careers-bg.jpg"
        primary={{ label: p.apply, href: mail }}
      />
    </SiteShell>
  );
}
