import ContactInfo from '@/components/blocks/ContactInfo';
import ContactSection from '@/components/sections/ContactSection';
import CoverageSection from '@/components/sections/CoverageSection';
import FaqSection from '@/components/sections/FaqSection';
import SiteShell from '@/components/site/SiteShell';
import { InnerHero, pageMetadata, resolvePage, staticParams } from '@/lib/pageKit';
import { href } from '@/lib/routes';

export const generateStaticParams = staticParams;
export const generateMetadata = pageMetadata('contact', (t) => t.pages.contact.hero);

export default async function ContactPage(props: { params: Promise<{ lang: string }> }) {
  const { lang, t } = await resolvePage(props);
  const p = t.pages.contact;

  return (
    <SiteShell lang={lang} formOnPage>
      <InnerHero lang={lang} slug="contact" hero={p.hero}>
        <a className="button" href="#inquiry">{t.form.title} <span>↓</span></a>
        <a className="hero-secondary" href="mailto:info@ranco.com.sa">info@ranco.com.sa <span>{t.arrow}</span></a>
      </InnerHero>
      <ContactInfo t={t} />
      <ContactSection t={t} />
      <CoverageSection t={t} />
      <FaqSection t={t} items={t.faq.items.slice(0, 4)} more={{ label: t.pages.viewAll, href: href(lang, 'faq') }} />
    </SiteShell>
  );
}
