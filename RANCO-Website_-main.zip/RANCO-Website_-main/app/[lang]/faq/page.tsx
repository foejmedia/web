import ExploreNext from '@/components/blocks/ExploreNext';
import FaqSection from '@/components/sections/FaqSection';
import SiteShell from '@/components/site/SiteShell';
import { InnerHero, PageCta, pageMetadata, resolvePage, staticParams } from '@/lib/pageKit';
import { href } from '@/lib/routes';

export const generateStaticParams = staticParams;
export const generateMetadata = pageMetadata('faq', (t) => t.pages.faq.hero);

export default async function FaqPage(props: { params: Promise<{ lang: string }> }) {
  const { lang, t } = await resolvePage(props);
  const p = t.pages.faq;

  return (
    <SiteShell lang={lang}>
      <InnerHero lang={lang} slug="faq" hero={p.hero}>
        <a className="button" href={href(lang, 'contact', 'inquiry')}>{t.nav.quote} <span>{t.arrow}</span></a>
        <a className="hero-secondary" href={href(lang, 'contact')}>{t.nav.contact} <span>{t.arrow}</span></a>
      </InnerHero>
      <FaqSection t={t} items={[...t.faq.items, ...p.more]} />
      <ExploreNext lang={lang} slugs={['services', 'fleet', 'contact']} />
      <PageCta lang={lang} />
    </SiteShell>
  );
}
