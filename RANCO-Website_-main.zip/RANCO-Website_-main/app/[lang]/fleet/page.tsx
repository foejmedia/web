import CatalogueGrid from '@/components/blocks/CatalogueGrid';
import ExploreNext from '@/components/blocks/ExploreNext';
import ProcessSteps from '@/components/blocks/ProcessSteps';
import RigMoveScroll from '@/components/RigMoveScroll';
import FleetSection from '@/components/sections/FleetSection';
import StatsSection from '@/components/sections/StatsSection';
import SiteShell from '@/components/site/SiteShell';
import { InnerHero, PageCta, pageMetadata, resolvePage, staticParams } from '@/lib/pageKit';
import { href } from '@/lib/routes';

export const generateStaticParams = staticParams;
export const generateMetadata = pageMetadata('fleet', (t) => t.pages.fleet.hero);

export default async function FleetPage(props: { params: Promise<{ lang: string }> }) {
  const { lang, t } = await resolvePage(props);
  const p = t.pages.fleet;

  return (
    <SiteShell lang={lang}>
      <InnerHero lang={lang} slug="fleet" hero={p.hero}>
        <a className="button" href={`${href(lang, 'contact')}?service=1#inquiry`}>{t.nav.quote} <span>{t.arrow}</span></a>
        <a className="hero-secondary" href={href(lang, 'services')}>{t.nav.services} <span>{t.arrow}</span></a>
      </InnerHero>
      <FleetSection t={t} />
      <CatalogueGrid t={p.catalogue} />
      <RigMoveScroll t={t.rig} />
      <ProcessSteps {...p.readiness} tone="dark" />
      <StatsSection t={t} />
      <ExploreNext lang={lang} slugs={['services', 'qhse', 'industries']} />
      <PageCta lang={lang} image="/assets/photos/fleet-logistics.jpg" />
    </SiteShell>
  );
}
