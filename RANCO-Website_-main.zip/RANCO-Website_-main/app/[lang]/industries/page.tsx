import CapabilityMatrix from '@/components/blocks/CapabilityMatrix';
import ExploreNext from '@/components/blocks/ExploreNext';
import CoverageSection from '@/components/sections/CoverageSection';
import IndustriesSection from '@/components/sections/IndustriesSection';
import WhySection from '@/components/sections/WhySection';
import SiteShell from '@/components/site/SiteShell';
import { InnerHero, PageCta, pageMetadata, resolvePage, staticParams } from '@/lib/pageKit';
import { href } from '@/lib/routes';

export const generateStaticParams = staticParams;
export const generateMetadata = pageMetadata('industries', (t) => t.pages.industries.hero);

export default async function IndustriesPage(props: { params: Promise<{ lang: string }> }) {
  const { lang, t } = await resolvePage(props);
  const p = t.pages.industries;

  return (
    <SiteShell lang={lang}>
      <InnerHero lang={lang} slug="industries" hero={p.hero}>
        <a className="button" href={href(lang, 'services')}>{t.nav.services} <span>{t.arrow}</span></a>
        <a className="hero-secondary" href={href(lang, 'contact', 'inquiry')}>{t.nav.quote} <span>{t.arrow}</span></a>
      </InnerHero>
      <IndustriesSection t={t} />
      <CapabilityMatrix t={t} />
      <WhySection t={t} />
      <CoverageSection t={t} />
      <ExploreNext lang={lang} slugs={['services', 'fleet', 'vision-2030']} />
      <PageCta lang={lang} />
    </SiteShell>
  );
}
