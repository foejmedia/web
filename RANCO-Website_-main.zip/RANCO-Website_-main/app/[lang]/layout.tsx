import type { Metadata, Viewport } from 'next';
import { Figtree, IBM_Plex_Sans_Arabic, Schibsted_Grotesk } from 'next/font/google';
import { notFound } from 'next/navigation';
import { themeInitScript } from '@/components/ThemeToggle';
import { dictionaries, isLocale, locales } from '@/lib/dictionaries';
import '../globals.css';
import '../features.css';
import '../sections.css';
import '../pages.css';
import '../sphere.css';
import '../theme.css';
import '../light.css';

const arabic = IBM_Plex_Sans_Arabic({ subsets: ['arabic'], weight: ['400', '500', '600', '700'], variable: '--font-ar', display: 'swap' });
const display = Schibsted_Grotesk({ subsets: ['latin'], weight: ['500', '600', '700', '800'], variable: '--font-display', display: 'swap' });
const body = Figtree({ subsets: ['latin'], weight: ['400', '500', '600', '700'], variable: '--font-body', display: 'swap' });

export const dynamicParams = false;

export function generateStaticParams() {
  return locales.map((lang) => ({ lang }));
}

export async function generateMetadata({ params }: { params: Promise<{ lang: string }> }): Promise<Metadata> {
  const { lang } = await params;
  if (!isLocale(lang)) return {};
  const t = dictionaries[lang].meta;
  return {
    title: t.title,
    description: t.description,
    alternates: { languages: { en: '/en', ar: '/ar' } },
  };
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0b0c0e',
};

export default async function RootLayout({ children, params }: { children: React.ReactNode; params: Promise<{ lang: string }> }) {
  const { lang } = await params;
  if (!isLocale(lang)) notFound();
  return (
    <html lang={lang} dir={lang === 'ar' ? 'rtl' : 'ltr'} data-theme="dark" className={`${arabic.variable} ${display.variable} ${body.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
