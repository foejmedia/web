import { notFound } from 'next/navigation';
import OilGasTracker from '@/components/OilGasTracker';
import SiteShell from '@/components/site/SiteShell';
import { isLocale, locales } from '@/lib/dictionaries';

export function generateStaticParams() {
  return locales.map((lang) => ({ lang }));
}

export default async function OilGasPricesPage({ params }: { params: Promise<{ lang: string }> }) {
  const { lang } = await params;
  if (!isLocale(lang)) notFound();

  return (
    <SiteShell lang={lang} mainClassName="tracker-page">
      <OilGasTracker lang={lang} />
    </SiteShell>
  );
}
