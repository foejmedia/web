import { notFound } from 'next/navigation';
import CountUp from '@/components/CountUp';
import CtaBanner from '@/components/blocks/CtaBanner';
import RigMoveScroll from '@/components/RigMoveScroll';
import SphereGallery from '@/components/SphereGallery';
import AboutSection from '@/components/sections/AboutSection';
import CareersSection from '@/components/sections/CareersSection';
import ClientsStrip from '@/components/sections/ClientsStrip';
import ContactSection from '@/components/sections/ContactSection';
import CoverageSection from '@/components/sections/CoverageSection';
import FaqSection from '@/components/sections/FaqSection';
import FleetSection from '@/components/sections/FleetSection';
import IndustriesSection from '@/components/sections/IndustriesSection';
import JourneySection from '@/components/sections/JourneySection';
import QhseSection from '@/components/sections/QhseSection';
import ServicesSection from '@/components/sections/ServicesSection';
import StatsSection from '@/components/sections/StatsSection';
import VisionSection from '@/components/sections/VisionSection';
import WhySection from '@/components/sections/WhySection';
import SiteShell from '@/components/site/SiteShell';
import { contacts } from '@/lib/data';
import { dictionaries, isLocale } from '@/lib/dictionaries';
import { href } from '@/lib/routes';

export default async function Home({ params }: { params: Promise<{ lang: string }> }) {
  const { lang } = await params;
  if (!isLocale(lang)) notFound();
  const t = dictionaries[lang];
  const a = t.arrow;
  const more = (slug: Parameters<typeof href>[1], label = t.pages.viewAll) => ({ label, href: href(lang, slug) });

  return (
    <SiteShell lang={lang} formOnPage>
      <section className="hero" id="home">
        <div className="hero-image" role="img" aria-label={t.hero.imageAlt}></div>
        <div className="hero-copy">
          <p className="eyebrow"><span className="live-dot"></span> {t.hero.eyebrow}</p>
          <h1>
            <span className="line"><span>{t.hero.line1}</span></span>
            <span className="line"><span>{t.hero.line2}<em>{t.hero.line2Em}</em></span></span>
          </h1>
          <p className="lead">{t.hero.lead1}<br />{t.hero.lead2}</p>
          <div className="actions">
            <a className="button" href={href(lang, 'services')}>{t.hero.cta} <span>{a}</span></a>
            <a className="hero-secondary" href={href(lang, 'contact')}>{t.hero.talk} <span>{a}</span></a>
          </div>
        </div>
        <div className="hero-bottom">
          <div><strong><CountUp to={22} /><span>+</span></strong><small>{t.hero.stat1[0]}<br />{t.hero.stat1[1]}</small></div>
          <div><strong><CountUp to={8} pad={2} /></strong><small>{t.hero.stat2[0]}<br />{t.hero.stat2[1]}</small></div>
          <a href="#about" className="scroll-cue">{t.hero.explore} <span>↓</span></a>
        </div>
        <span className="image-note">{t.hero.imageNote}</span>
      </section>
      <div className="sector-strip">
        {t.sectors.map((s, i) => (
          <span key={s} data-reveal data-d={String(i + 1)}>{s}</span>
        ))}
      </div>

      <ClientsStrip t={t} />
      <AboutSection t={t} />
      <ServicesSection t={t} more={more('services')} footerHref="#inquiry" />
      <IndustriesSection t={t} more={more('industries')} />
      <RigMoveScroll t={t.rig} />
      <FleetSection t={t} more={more('fleet')} />
      <SphereGallery t={t.sphere} ctaHref="#inquiry" arrow={a} />
      <JourneySection t={t} />
      <WhySection t={t} />
      <StatsSection t={t} />
      <QhseSection t={t} more={more('qhse', t.nav.qhse)} />
      <VisionSection t={t} more={more('vision-2030', t.nav.vision)} />
      <CoverageSection t={t} />
      <CareersSection t={t} />
      <FaqSection t={t} items={t.faq.items.slice(0, 4)} more={more('faq')} />
      <CtaBanner
        {...t.cta}
        arrow={a}
        primary={{ label: t.cta.primary, href: '#inquiry' }}
        secondary={{ label: t.cta.secondary, href: `tel:${contacts[0].phone.replaceAll(' ', '')}` }}
      />
      <ContactSection t={t} />
    </SiteShell>
  );
}
