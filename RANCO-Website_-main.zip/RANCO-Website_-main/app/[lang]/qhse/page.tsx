import CardGrid from '@/components/blocks/CardGrid';
import ExploreNext from '@/components/blocks/ExploreNext';
import SectionHead from '@/components/blocks/SectionHead';
import StandardsShowcase from '@/components/blocks/StandardsShowcase';
import QhseSection from '@/components/sections/QhseSection';
import StatsSection from '@/components/sections/StatsSection';
import SiteShell from '@/components/site/SiteShell';
import { valueIcons, whyIcons } from '@/lib/data';
import { InnerHero, PageCta, pageMetadata, resolvePage, staticParams } from '@/lib/pageKit';
import { href } from '@/lib/routes';

export const generateStaticParams = staticParams;
export const generateMetadata = pageMetadata('qhse', (t) => t.pages.qhse.hero);

// Icons for the six safety principles, picked from the shared icon sets.
const principleIcons = [whyIcons[0], valueIcons[1], whyIcons[2], valueIcons[4], whyIcons[4], valueIcons[3]];

export default async function QhsePage(props: { params: Promise<{ lang: string }> }) {
  const { lang, t } = await resolvePage(props);
  const p = t.pages.qhse;

  return (
    <SiteShell lang={lang}>
      <InnerHero lang={lang} slug="qhse" hero={p.hero}>
        <a className="button" href="#principles">{p.principles.eyebrow} <span>↓</span></a>
        <a className="hero-secondary" href={href(lang, 'contact')}>{t.nav.contact} <span>{t.arrow}</span></a>
      </InnerHero>
      <QhseSection t={t} />
      <section className="section band-light" id="principles">
        <SectionHead eyebrow={p.principles.eyebrow} h2a={p.principles.h2a} h2Em={p.principles.h2Em} />
        <CardGrid items={p.principles.items} icons={principleIcons} columns={3} />
      </section>
      <StatsSection t={t} />
      <StandardsShowcase t={t} />
      <ExploreNext lang={lang} slugs={['about', 'careers', 'vision-2030']} />
      <PageCta lang={lang} />
    </SiteShell>
  );
}
