import ExploreNext from '@/components/blocks/ExploreNext';
import ProcessSteps from '@/components/blocks/ProcessSteps';
import SectionHead from '@/components/blocks/SectionHead';
import SplitFeature from '@/components/blocks/SplitFeature';
import RigMoveScroll from '@/components/RigMoveScroll';
import FaqSection from '@/components/sections/FaqSection';
import ServicesSection from '@/components/sections/ServicesSection';
import SiteShell from '@/components/site/SiteShell';
import { serviceImages } from '@/lib/data';
import { InnerHero, PageCta, pageMetadata, resolvePage, staticParams } from '@/lib/pageKit';
import { href } from '@/lib/routes';

export const generateStaticParams = staticParams;
export const generateMetadata = pageMetadata('services', (t) => t.pages.services.hero);

export default async function ServicesPage(props: { params: Promise<{ lang: string }> }) {
  const { lang, t } = await resolvePage(props);
  const p = t.pages.services;
  const contact = (i: number) => `${href(lang, 'contact')}?service=${i}#inquiry`;

  return (
    <SiteShell lang={lang}>
      <InnerHero lang={lang} slug="services" hero={p.hero}>
        <a className="button" href="#service-detail">{p.detail.eyebrow} <span>↓</span></a>
        <a className="hero-secondary" href={href(lang, 'contact', 'inquiry')}>{t.nav.quote} <span>{t.arrow}</span></a>
      </InnerHero>

      <ServicesSection t={t} footerHref={href(lang, 'contact', 'inquiry')} />

      <section className="section split-list" id="service-detail">
        <SectionHead eyebrow={p.detail.eyebrow} h2a={p.detail.h2a} h2Em={p.detail.h2Em} breakTitle={false} />
        {t.services.items.map((s, i) => (
          <SplitFeature
            key={s.title}
            image={serviceImages[i]}
            index={String(i + 1).padStart(2, '0')}
            teaser={s.teaser}
            title={s.title}
            body={s.description}
            points={p.detail.points[i]}
            reverse={i % 2 === 1}
          >
            <a className="textlink" href={contact(i)}>{p.detail.cta} {t.arrow}</a>
          </SplitFeature>
        ))}
      </section>

      <RigMoveScroll t={t.rig} />
      <ProcessSteps {...p.process} />
      <FaqSection t={t} items={t.faq.items.slice(1, 5)} more={{ label: t.pages.viewAll, href: href(lang, 'faq') }} />
      <ExploreNext lang={lang} slugs={['industries', 'fleet', 'qhse']} />
      <PageCta lang={lang} />
    </SiteShell>
  );
}
