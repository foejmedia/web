import ExploreNext from '@/components/blocks/ExploreNext';
import QuoteBlock from '@/components/blocks/QuoteBlock';
import SectionHead from '@/components/blocks/SectionHead';
import SplitFeature from '@/components/blocks/SplitFeature';
import VisionSection from '@/components/sections/VisionSection';
import SiteShell from '@/components/site/SiteShell';
import { InnerHero, PageCta, pageMetadata, resolvePage, staticParams } from '@/lib/pageKit';
import { href } from '@/lib/routes';

export const generateStaticParams = staticParams;
export const generateMetadata = pageMetadata('vision-2030', (t) => t.pages.vision.hero);

const commitmentImages = ['team', 'construction', 'power', 'dashboard'].map((n) => `/assets/photos/${n}.jpg`);

export default async function VisionPage(props: { params: Promise<{ lang: string }> }) {
  const { lang, t } = await resolvePage(props);
  const p = t.pages.vision;

  return (
    <SiteShell lang={lang}>
      <InnerHero lang={lang} slug="vision-2030" hero={p.hero}>
        <a className="button" href="#commitments">{p.commitments.eyebrow} <span>↓</span></a>
        <a className="hero-secondary" href={href(lang, 'about')}>{t.nav.about} <span>{t.arrow}</span></a>
      </InnerHero>
      <VisionSection t={t} />
      <section className="section split-list" id="commitments">
        <SectionHead eyebrow={p.commitments.eyebrow} h2a={p.commitments.h2a} h2Em={p.commitments.h2Em} breakTitle={false} />
        {p.commitments.items.map((c, i) => (
          <SplitFeature
            key={c.title}
            image={commitmentImages[i]}
            index={String(i + 1).padStart(2, '0')}
            teaser={t.vision.pillars[i].title}
            title={c.title}
            body={c.p}
            reverse={i % 2 === 1}
          />
        ))}
      </section>
      <QuoteBlock
        eyebrow={t.pages.about.leadership}
        quote={t.about.quote}
        body={t.about.body2}
        name={t.about.chairmanName}
        role={t.about.chairmanTitle}
        image="/assets/photos/power.jpg"
      />
      <ExploreNext lang={lang} slugs={['about', 'careers', 'industries']} />
      <PageCta lang={lang} image="/assets/photos/vision-desert.jpg" />
    </SiteShell>
  );
}
