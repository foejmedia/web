'use client';

import { useEffect, useRef } from 'react';

type Props = { to: number; pad?: number; duration?: number; separate?: boolean };

export default function CountUp({ to, pad = 0, duration = 1600, separate = false }: Props) {
  const ref = useRef<HTMLElement>(null);
  const fmt = (n: number) => (separate ? n.toLocaleString('en-US') : String(n)).padStart(pad, '0');

  useEffect(() => {
    const el = ref.current;
    if (!el || to === 0 || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    let raf = 0;
    el.textContent = fmt(0);
    const run = () => {
      const t0 = performance.now();
      const tick = (t: number) => {
        const p = Math.min((t - t0) / duration, 1);
        el.textContent = fmt(Math.round(to * (1 - Math.pow(1 - p, 3))));
        if (p < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    };
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          io.disconnect();
          run();
        }
      },
      { threshold: 0.6 },
    );
    io.observe(el);

    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [to, pad, duration, separate]);

  return (
    <i ref={ref} className="count">
      {fmt(to)}
    </i>
  );
}
