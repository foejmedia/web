'use client';

import { useState } from 'react';
import { locations, type Location } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';
import { MAP_H, MAP_W, project, saudiPath } from '@/lib/saudiMap';

type Region = Location['region'];
type Filter = 'all' | Region;

const points = locations.map((l) => ({ ...l, ...project(l.lon, l.lat) }));
const hubs = points.filter((p) => p.hub);
// Curved "corridor" lines between operations hubs.
const corridors = hubs.slice(1).map((h, i) => {
  const a = hubs[i];
  const mx = (a.x + h.x) / 2;
  const my = (a.y + h.y) / 2 - 70;
  return `M${a.x} ${a.y} Q${mx} ${my} ${h.x} ${h.y}`;
});

export default function CoverageMap({ t }: { t: Dictionary['map'] }) {
  const [filter, setFilter] = useState<Filter>('all');
  const [active, setActive] = useState<string>(hubs[0].id);

  const visible = (r: Region) => filter === 'all' || filter === r;
  const current = points.find((p) => p.id === active);
  const filters: Filter[] = ['all', 'east', 'central', 'west'];

  const pick = (f: Filter) => {
    setFilter(f);
    if (f !== 'all' && current?.region !== f) setActive(points.find((p) => p.region === f)!.id);
  };

  return (
    <div className="map-layout">
      <div className="map-canvas" data-reveal="zoom">
        <svg viewBox={`0 0 ${MAP_W} ${MAP_H}`} role="img" aria-label={t.lead}>
          <defs>
            <pattern id="map-dots" width="14" height="14" patternUnits="userSpaceOnUse">
              <circle cx="7" cy="7" r="2.2" className="map-dot" />
            </pattern>
            <clipPath id="map-clip">
              <path d={saudiPath} />
            </clipPath>
          </defs>
          <path d={saudiPath} className="map-land" />
          <rect width={MAP_W} height={MAP_H} fill="url(#map-dots)" clipPath="url(#map-clip)" />
          <path d={saudiPath} className="map-border" />
          {corridors.map((d) => (
            <path key={d} d={d} className="map-corridor" />
          ))}
          {points.map((p) => {
            const on = p.id === active;
            return (
              <g
                key={p.id}
                className={'map-pin' + (p.hub ? ' hub' : '') + (on ? ' on' : '') + (visible(p.region) ? '' : ' dim')}
                transform={`translate(${p.x} ${p.y})`}
                onClick={() => setActive(p.id)}
                onMouseEnter={() => setActive(p.id)}
              >
                <circle className="map-pulse" r={p.hub ? 12 : 8} />
                <circle className="map-core" r={p.hub ? 9 : 6} />
                {(p.hub || on) && (
                  <text x={p.x > 820 ? -16 : 16} y={5} textAnchor={p.x > 820 ? 'end' : 'start'}>
                    {t.names[p.id]}
                  </text>
                )}
              </g>
            );
          })}
        </svg>
      </div>

      <div className="map-side" data-reveal="right" data-d="2">
        <div className="map-filters" role="group">
          {filters.map((f) => (
            <button key={f} type="button" className={filter === f ? 'on' : undefined} aria-pressed={filter === f} onClick={() => pick(f)}>
              {t.filters[f]}
            </button>
          ))}
        </div>

        {current && (
          <div className="map-card" key={current.id}>
            <span className="map-kind">{current.hub ? t.hub : t.site}</span>
            <strong>{t.names[current.id]}</strong>
            <small>{t.filters[current.region]}</small>
          </div>
        )}

        <ul className="map-list">
          {points
            .filter((p) => visible(p.region))
            .map((p) => (
              <li key={p.id}>
                <button type="button" className={p.id === active ? 'on' : undefined} onClick={() => setActive(p.id)}>
                  <span className={'map-bullet' + (p.hub ? ' hub' : '')} aria-hidden="true"></span>
                  {t.names[p.id]}
                  <small>{p.hub ? t.hub : t.site}</small>
                </button>
              </li>
            ))}
        </ul>
        <p className="map-hint">{t.hint}</p>
      </div>
    </div>
  );
}
