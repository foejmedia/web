'use client';

import { useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import type { Dictionary, Locale } from '@/lib/dictionaries';
import { blurbKey, href, type PageSlug } from '@/lib/routes';
import ThemeToggle from './ThemeToggle';

type Props = {
  lang: Locale;
  nav: Dictionary['nav'];
  blurbs: Record<string, string>;
  arrow: string;
  switchLabel: string;
  switchAria: string;
  themeLabels: Dictionary['theme'];
};

const Chevron = () => (
  <svg className="nav-chevron" viewBox="0 0 16 16" aria-hidden="true">
    <path d="m3.5 6 4.5 4 4.5-4" />
  </svg>
);

const groups: { key: 'about' | 'services'; slugs: PageSlug[] }[] = [
  { key: 'about', slugs: ['about', 'vision-2030', 'qhse', 'careers'] },
  { key: 'services', slugs: ['services', 'industries', 'fleet', 'faq'] },
];

const label = (nav: Dictionary['nav'], slug: PageSlug) => nav[(slug === 'vision-2030' ? 'vision' : slug) as keyof Dictionary['nav']];

export default function Header({ lang, nav, blurbs, arrow, switchLabel, switchAria, themeLabels }: Props) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname() || `/${lang}`;
  const other = lang === 'en' ? 'ar' : 'en';
  const otherPath = pathname.replace(/^\/(en|ar)(?=\/|$)/, `/${other}`);
  const current = pathname.split('/')[2] ?? '';

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    document.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('scroll', onScroll);
      document.removeEventListener('keydown', onKey);
    };
  }, []);

  const close = () => setOpen(false);
  const active = (slugs: string[]) => (slugs.includes(current) ? 'active' : undefined);

  return (
    <header className={scrolled ? 'scrolled' : undefined}>
      <a className="brand" href={href(lang)} aria-label={nav.home}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img className="logo-on-dark" src="/assets/ranco-logo-dark.png" alt="RANCO" />
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img className="logo-on-light" src="/assets/ranco-logo-light.png" alt="" aria-hidden="true" />
      </a>
      <button className="menu" aria-expanded={open} aria-controls="nav" onClick={() => setOpen((o) => !o)}>
        {nav.menu} ☰
      </button>
      <nav id="nav" className={open ? 'open' : undefined}>
        <a className={current === '' ? 'active' : undefined} href={href(lang)} onClick={close}>{nav.home}</a>
        {groups.map((g) => (
          <div className="nav-item" key={g.key}>
            <a className={`has-arrow ${active(g.slugs) ?? ''}`} href={href(lang, g.key)} onClick={close}>
              {nav[g.key]}
              <Chevron />
            </a>
            <div className="mega-menu" aria-label={`${nav[g.key]} links`}>
              {g.slugs.map((slug) => (
                <a href={href(lang, slug)} onClick={close} key={slug} className={current === slug ? 'current' : undefined}>
                  <span className="mega-text">
                    <strong>{label(nav, slug)}</strong>
                    <small>{blurbs[blurbKey[slug]]}</small>
                  </span>
                  <span className="mega-arrow" aria-hidden="true">{arrow}</span>
                </a>
              ))}
            </div>
          </div>
        ))}
        <a className={active(['qhse'])} href={href(lang, 'qhse')} onClick={close}>{nav.qhse}</a>
        <a className={active(['careers'])} href={href(lang, 'careers')} onClick={close}>{nav.careers}</a>
        <a className={active(['contact'])} href={href(lang, 'contact')} onClick={close}>{nav.contact}</a>
        <a className={`price-link${current === 'oil-gas-prices' ? ' active' : ''}`} href={`/${lang}/oil-gas-prices`} onClick={close} aria-label={nav.oilPrices} title={nav.oilPrices}>
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4h10M8 4v3l-2 2v10h12V9l-2-2V4M6 13h12M8.5 16h.01M12 16h.01M15.5 16h.01" /></svg>
        </a>
        <ThemeToggle labels={themeLabels} />
        <a className="lang-switch" href={otherPath} hrefLang={other} lang={other} aria-label={switchAria}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
            <circle cx="12" cy="12" r="9" />
            <path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z" />
          </svg>
          {switchLabel}
        </a>
        <a className="button nav-quote" href={href(lang, 'contact', 'inquiry')} onClick={close}>{nav.quote} {arrow}</a>
      </nav>
    </header>
  );
}
