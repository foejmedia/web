'use client';

import { useEffect, useState, type FormEvent } from 'react';
import { contacts, GENERAL_CONTACT_INDEX, services } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';
import { useInquiry } from './InquiryProvider';

type Props = { t: Dictionary['form']; serviceTitles: string[]; arrow: string };

export default function InquiryForm({ t, serviceTitles, arrow }: Props) {
  const { service, setService } = useInquiry();
  const [status, setStatus] = useState(t.status);

  // Preselect a service passed from another page as ?service=<index>.
  useEffect(() => {
    const s = new URLSearchParams(window.location.search).get('service');
    if (s && services[Number(s)]) setService(s);
  }, [setService]);

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const idx = Number(f.get('service'));
    const selected = services[idx];
    const to = contacts[selected ? selected.contactIndex : GENERAL_CONTACT_INDEX].email;
    const subject = t.subjectPrefix + (selected ? serviceTitles[idx] : t.general);
    const body = `${t.mail.name}: ${f.get('name')}\n${t.mail.company}: ${f.get('company')}\n${t.mail.email}: ${f.get('email')}\n\n${t.mail.requirements}:\n${f.get('message')}`;
    window.location.href = `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    setStatus(t.sent.replace('{to}', to));
  };

  return (
    <form id="inquiry" onSubmit={onSubmit} data-reveal="right" data-d="2">
      <h3>{t.title}</h3>
      <p>{t.intro}</p>
      <div className="form-row">
        <label>
          {t.name}
          <input name="name" autoComplete="name" required placeholder={t.namePh} />
        </label>
        <label>
          {t.company}
          <input name="company" autoComplete="organization" placeholder={t.companyPh} />
        </label>
      </div>
      <label>
        {t.email}
        <input type="email" name="email" autoComplete="email" required placeholder={t.emailPh} dir="ltr" />
      </label>
      <label>
        {t.service}
        <select name="service" id="service-select" value={service} onChange={(e) => setService(e.target.value)}>
          <option value="general">{t.general}</option>
          {serviceTitles.map((title, i) => (
            <option key={i} value={i}>
              {title}
            </option>
          ))}
        </select>
      </label>
      <label>
        {t.message}
        <textarea name="message" required rows={4} placeholder={t.messagePh} />
      </label>
      <button className="button" type="submit">
        {t.submit} {arrow}
      </button>
      <small id="form-status" aria-live="polite">
        {status}
      </small>
    </form>
  );
}
