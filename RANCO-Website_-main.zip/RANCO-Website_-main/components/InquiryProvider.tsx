'use client';

import { createContext, useContext, useState, type ReactNode } from 'react';

type InquiryState = {
  service: string;
  setService: (value: string) => void;
  // Link to the inquiry form, preselecting a service when the form lives on another page.
  inquiryHref: (service?: string) => string;
};

const InquiryContext = createContext<InquiryState | null>(null);

// `formPath` is the page holding the form ('' when it is on the current page).
export function InquiryProvider({ children, formPath = '' }: { children: ReactNode; formPath?: string }) {
  const [service, setService] = useState('general');
  const inquiryHref = (s?: string) => (formPath ? `${formPath}${s ? `?service=${s}` : ''}#inquiry` : '#inquiry');
  return <InquiryContext.Provider value={{ service, setService, inquiryHref }}>{children}</InquiryContext.Provider>;
}

export function useInquiry() {
  const ctx = useContext(InquiryContext);
  if (!ctx) throw new Error('useInquiry must be used within InquiryProvider');
  return ctx;
}
