'use client';

import { useEffect, useState } from 'react';
import type { Locale } from '@/lib/dictionaries';

type Props = { lang: Locale };

const prices = [
  { key: 'brent', en: 'Brent Crude', ar: 'خام برنت', value: '74.82', unit: '$ / BBL', change: '+1.24%', tone: 'up' },
  { key: 'wti', en: 'WTI Crude', ar: 'خام غرب تكساس', value: '71.46', unit: '$ / BBL', change: '+0.87%', tone: 'up' },
  { key: 'gas', en: 'Natural Gas', ar: 'الغاز الطبيعي', value: '3.18', unit: '$ / MMBTU', change: '-0.42%', tone: 'down' },
];

export default function OilGasTracker({ lang }: Props) {
  const [updatedAt, setUpdatedAt] = useState(() => new Date());
  const isArabic = lang === 'ar';

  useEffect(() => {
    const timer = window.setInterval(() => setUpdatedAt(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const copy = isArabic
    ? {
        live: 'متابعة مباشرة',
        title: 'أسعار النفط والغاز',
        intro: 'مؤشرات مرجعية تساعد فرقك على متابعة حركة أسواق الطاقة.',
        updated: 'آخر تحديث',
        reference: 'بيانات مرجعية — يتم تحديثها عند توفر مصدر السوق',
        view: 'تاريخ الأسعار',
        market: 'السوق مفتوح',
      }
    : {
        live: 'Live market watch',
        title: 'Oil & Gas Prices',
        intro: 'Reference indicators to help your team follow energy-market movement.',
        updated: 'Last updated',
        reference: 'Reference data — refreshed when a market feed is available',
        view: 'View price history',
        market: 'Market open',
      };

  return (
    <section className="tracker" dir={isArabic ? 'rtl' : 'ltr'}>
      <div className="tracker-shell">
        <div className="tracker-heading">
          <div>
            <p className="tracker-eyebrow"><span className="tracker-dot" />{copy.live}</p>
            <h1>{copy.title}</h1>
            <p className="tracker-intro">{copy.intro}</p>
          </div>
          <div className="tracker-status">
            <span className="status-pulse" />
            <strong>{copy.market}</strong>
            <small>{copy.updated} {updatedAt.toLocaleTimeString(isArabic ? 'ar-SA' : 'en-US')}</small>
          </div>
        </div>

        <div className="price-grid">
          {prices.map((price) => (
            <article className="price-card" key={price.key}>
              <div className="price-card-top">
                <span>{isArabic ? price.ar : price.en}</span>
                <span className="price-live">LIVE</span>
              </div>
              <strong>{price.value}</strong>
              <div className="price-card-bottom">
                <span>{price.unit}</span>
                <span className={`price-change ${price.tone}`}>{price.change}</span>
              </div>
              <span className="price-spark" aria-hidden="true">
                <i /><i /><i /><i /><i /><i /><i />
              </span>
            </article>
          ))}
        </div>

        <div className="tracker-footer">
          <span>{copy.reference}</span>
          <a href="#contact">{copy.view} <span aria-hidden="true">↗</span></a>
        </div>
      </div>
    </section>
  );
}
