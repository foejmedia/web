'use client';

import { useEffect, useRef, useState } from 'react';
import { RIG_MOVE_SERVICE_INDEX, rigMoveSteps } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';
import { useInquiry } from './InquiryProvider';

export default function RigMoveScroll({ t }: { t: Dictionary['rig'] }) {
  const ref = useRef<HTMLElement>(null);
  const [active, setActive] = useState(0);
  const { setService, inquiryHref } = useInquiry();

  useEffect(() => {
    const update = () => {
      const el = ref.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const scrollable = rect.height - window.innerHeight;
      const progress = scrollable > 0 ? Math.min(Math.max(-rect.top / scrollable, 0), 0.9999) : 0;
      setActive(Math.floor(progress * rigMoveSteps.length));
    };
    update();
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    return () => {
      window.removeEventListener('scroll', update);
      window.removeEventListener('resize', update);
    };
  }, []);

  const goTo = (i: number) => {
    const el = ref.current;
    if (!el) return;
    const scrollable = el.offsetHeight - window.innerHeight;
    const top = el.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({ top: top + ((i + 0.5) / rigMoveSteps.length) * scrollable, behavior: 'smooth' });
  };

  return (
    <section className="rigmove" id="rig-move" ref={ref} style={{ height: `${rigMoveSteps.length * 100}vh` }}>
      <div className="rigmove-sticky">
        <div className="rigmove-images" aria-hidden="true">
          {rigMoveSteps.map((s, i) => (
            <div
              key={s.image}
              className={'rigmove-image' + (i === active ? ' on' : '')}
              style={{ backgroundImage: `url('${s.image}')`, transformOrigin: s.position, '--z': s.zoom } as React.CSSProperties}
            />
          ))}
        </div>
        <div className="rigmove-shade" aria-hidden="true"></div>

        <div className="rigmove-copy">
          <p className="rigmove-eyebrow" data-reveal>{t.eyebrow}</p>
          <h2 data-reveal data-d="1">{t.h2[0]}<br />{t.h2[1]}</h2>
          <p className="rigmove-lead" data-reveal data-d="2">
            {t.lead}
          </p>

          <ol className="rigmove-steps" data-reveal data-d="3">
            {rigMoveSteps.map((s, i) => (
              <li key={s.image} className={i === active ? 'on' : undefined}>
                <button type="button" onClick={() => goTo(i)} aria-current={i === active ? 'step' : undefined}>
                  <span className="n">0{i + 1}</span>
                  <span className="t">{t.steps[i].title}</span>
                </button>
                <p className="d">{t.steps[i].description}</p>
              </li>
            ))}
          </ol>

          <p className="rigmove-tag" data-reveal data-d="4">{t.tag}</p>
          <div data-reveal data-d="5">
            <a className="button" href={inquiryHref(String(RIG_MOVE_SERVICE_INDEX))} onClick={() => setService(String(RIG_MOVE_SERVICE_INDEX))}>
              {t.cta}
            </a>
          </div>
        </div>

        <div className="rigmove-counter" aria-hidden="true">
          <span key={active} className="tick">0{active + 1}</span> / 0{rigMoveSteps.length}
        </div>
      </div>
    </section>
  );
}
