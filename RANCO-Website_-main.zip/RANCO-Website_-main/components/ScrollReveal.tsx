'use client';

import { useEffect } from 'react';

// Adds `.in` to every [data-reveal] element the first time it scrolls into view.
// Hidden styles only apply under `html.js`, so the page stays readable without JavaScript.
export default function ScrollReveal() {
  useEffect(() => {
    const root = document.documentElement;
    root.classList.add('js');

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('in');
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -6% 0px' },
    );
    document.querySelectorAll('[data-reveal]').forEach((el) => io.observe(el));

    return () => {
      io.disconnect();
      root.classList.remove('js');
    };
  }, []);

  return null;
}
