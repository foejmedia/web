'use client';

import { services } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';
import { useInquiry } from './InquiryProvider';

type Props = { t: Dictionary['services']; arrow: string };

export default function ServiceList({ t, arrow }: Props) {
  const { setService, inquiryHref } = useInquiry();

  return (
    <div id="service-list">
      {services.map((s, i) => (
        <details className="service" key={i} data-reveal data-d={(i % 4) + 1}>
          <summary>
            <span className="service-top">
              <span className="service-icon">
                <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d={s.icon} />
                </svg>
              </span>
              <span className="number">0{i + 1}</span>
            </span>
            <h3>{t.items[i].title}</h3>
            <span className="service-teaser">{t.items[i].teaser}</span>
            <span className="card-bottom">
              {t.explore} <span className="plus">{arrow}</span>
            </span>
          </summary>
          <div className="service-content">
            {t.items[i].description}
            <br />
            <a className="textlink" href={inquiryHref(String(i))} onClick={() => setService(String(i))}>
              {t.discuss} {arrow}
            </a>
          </div>
        </details>
      ))}
    </div>
  );
}
