'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { sphereImages } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';

type Props = { t: Dictionary['sphere']; ctaHref: string; arrow: string };

const CARD_COUNT = 24;
const TURNS = 2; // full Y rotations across the scroll length
const TILT = 45; // degrees of X tilt reached at the end

// Even distribution of points on a sphere (Fibonacci lattice), as unit vectors.
const lattice = Array.from({ length: CARD_COUNT }, (_, i) => {
  const phi = Math.acos(1 - (2 * (i + 0.5)) / CARD_COUNT);
  const theta = Math.PI * (1 + Math.sqrt(5)) * i;
  return { x: Math.cos(theta) * Math.sin(phi), y: Math.sin(theta) * Math.sin(phi), z: Math.cos(phi) };
});

const scatter = [
  { top: '10%', left: '12%' },
  { top: '18%', left: '80%' },
  { top: '58%', left: '6%' },
  { top: '72%', left: '84%' },
  { top: '82%', left: '28%' },
  { top: '8%', left: '50%' },
];

export default function SphereGallery({ t, ctaHref, arrow }: Props) {
  const trackRef = useRef<HTMLDivElement>(null);
  const sphereRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);
  const journeyRef = useRef<HTMLDivElement>(null);
  const floatRefs = useRef<(HTMLDivElement | null)[]>([]);
  const [radius, setRadius] = useState(380);
  const [step, setStep] = useState(0);

  // Random-but-stable tilt for the scattered cards (fixed so server and client render the same).
  const scatterTilt = useMemo(() => [-14, 11, -7, 16, -18, 6], []);

  useEffect(() => {
    const onResize = () => setRadius(window.innerWidth < 768 ? 190 : 380);
    onResize();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  useEffect(() => {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let current = 0;
    let target = 0;
    let frame = 0;
    let running = false;

    const progressOf = (el: HTMLElement | null) => {
      if (!el) return 0;
      const r = el.getBoundingClientRect();
      const span = r.height - window.innerHeight;
      return span > 0 ? Math.min(Math.max(-r.top / span, 0), 1) : 0;
    };

    const render = (p: number) => {
      const ay = p * 360 * TURNS;
      const ax = p * TILT;
      if (sphereRef.current) sphereRef.current.style.transform = `rotateX(${ax}deg) rotateY(${ay}deg)`;

      // Light up the cards that currently face the viewer.
      const sy = Math.sin((ay * Math.PI) / 180), cy = Math.cos((ay * Math.PI) / 180);
      const sx = Math.sin((ax * Math.PI) / 180), cx = Math.cos((ax * Math.PI) / 180);
      lattice.forEach((v, i) => {
        const z1 = -v.x * sy + v.z * cy;
        const z2 = v.y * sx + z1 * cx;
        cardRefs.current[i]?.classList.toggle('is-front', z2 > 0.72);
      });

      setStep(Math.min(Math.floor(p * t.items.length), t.items.length - 1));
    };

    const parallax = () => {
      const r = journeyRef.current?.getBoundingClientRect();
      if (!r) return;
      const p = Math.min(Math.max((window.innerHeight - r.top) / (window.innerHeight + r.height), 0), 1);
      floatRefs.current.forEach((el, i) => {
        if (el) el.style.translate = `0 ${-(p * 100) * (1 + i * 0.1)}px`;
      });
    };

    const tick = () => {
      current += (target - current) * 0.09;
      if (Math.abs(target - current) < 0.0005) current = target;
      render(current);
      if (current !== target) frame = requestAnimationFrame(tick);
      else running = false;
    };

    const onScroll = () => {
      target = progressOf(trackRef.current);
      if (!reduce) parallax();
      if (reduce) return render(0);
      if (!running) {
        running = true;
        frame = requestAnimationFrame(tick);
      }
    };

    target = current = progressOf(trackRef.current);
    render(reduce ? 0 : current);
    parallax();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, [t.items.length]);

  const item = t.items[step];

  return (
    <section className="sphere-section" aria-label={t.h2}>
      <div className="sphere-grid" aria-hidden="true"></div>

      <div className="sphere-intro">
        <span className="clay-badge" data-reveal>{t.badge}</span>
        <h2 data-reveal data-d="1">{t.h2}</h2>
        <p data-reveal data-d="2">{t.lead}</p>
      </div>

      <div className="sphere-track" ref={trackRef}>
        <div className="sphere-stage">
          <svg className="sphere-lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
            <path d="M0,50 Q25,30 50,50 T100,50" />
            <path d="M20,0 L80,100" />
          </svg>

          <div className="sphere-caption" aria-live="polite">
            <span className="sphere-count">{String(step + 1).padStart(2, '0')} / {String(t.items.length).padStart(2, '0')}</span>
            <div className="sphere-caption-body" key={step}>
              <h3>{item.title}</h3>
              <p>{item.desc}</p>
            </div>
          </div>

          <div className="sphere-scene" aria-hidden="true">
            <div className="sphere" ref={sphereRef}>
              {lattice.map((v, i) => {
                const x = v.x * radius, y = v.y * radius, z = v.z * radius;
                const rotY = (Math.atan2(x, z) * 180) / Math.PI;
                const rotX = (Math.asin(-v.y) * 180) / Math.PI;
                return (
                  <div
                    className="clay-card"
                    key={i}
                    ref={(el) => { cardRefs.current[i] = el; }}
                    style={{ transform: `translate3d(${x}px, ${y}px, ${z}px) rotateY(${rotY}deg) rotateX(${rotX}deg)` }}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={sphereImages[i % sphereImages.length]} alt="" decoding="async" />
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="sphere-journey" ref={journeyRef}>
        <div className="sphere-constellation" aria-hidden="true">
          {scatter.map((pos, i) => (
            <div
              className="clay-card constellation-card"
              key={i}
              ref={(el) => { floatRefs.current[i] = el; }}
              style={{ top: pos.top, left: pos.left, transform: `rotate(${scatterTilt[i]}deg) scale(.8)` }}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={sphereImages[(i * 3) % sphereImages.length]} alt="" loading="lazy" />
            </div>
          ))}
        </div>
        <div className="journey-glass" data-reveal="zoom">
          <h2>{t.journey.h2}</h2>
          <p>{t.journey.p}</p>
          <a className="clay-btn" href={ctaHref}>{t.journey.cta} <span>{arrow}</span></a>
        </div>
      </div>
    </section>
  );
}
