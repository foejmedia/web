'use client';

import { useEffect, useState } from 'react';
import { contacts, services, whatsappNumber } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';
import { useInquiry } from './InquiryProvider';

type Props = { t: Dictionary['whatsapp']; departments: string[]; serviceTitles: string[] };

const WhatsAppIcon = () => (
  <svg viewBox="0 0 32 32" aria-hidden="true">
    <path
      fill="currentColor"
      d="M16 3C8.8 3 3 8.7 3 15.8c0 2.5.7 4.9 2 7L3 29l6.4-2c2 1.1 4.3 1.7 6.6 1.7 7.2 0 13-5.7 13-12.8S23.2 3 16 3zm0 23.4c-2.1 0-4.1-.6-5.9-1.7l-.4-.2-3.8 1.2 1.2-3.7-.3-.4c-1.2-1.8-1.8-3.8-1.8-5.9C5 10 9.9 5.2 16 5.2S27 10 27 15.9s-4.9 10.5-11 10.5zm6-7.8c-.3-.2-2-1-2.3-1.1-.3-.1-.5-.2-.8.2-.2.3-.9 1.1-1.1 1.3-.2.2-.4.3-.7.1-.3-.2-1.4-.5-2.7-1.7-1-.9-1.7-2-1.9-2.3-.2-.3 0-.5.1-.7l.5-.6c.2-.2.2-.4.3-.6.1-.2 0-.4 0-.6l-1-2.5c-.3-.7-.6-.6-.8-.6h-.7c-.2 0-.6.1-.9.4-.3.3-1.2 1.2-1.2 2.9s1.2 3.3 1.4 3.6c.2.2 2.4 3.7 5.9 5.1 2.9 1.1 3.5.9 4.1.9.6-.1 2-.8 2.3-1.6.3-.8.3-1.5.2-1.6-.1-.2-.3-.3-.6-.4z"
    />
  </svg>
);

export default function WhatsAppWidget({ t, departments, serviceTitles }: Props) {
  const [open, setOpen] = useState(false);
  const { service } = useInquiry();

  const idx = Number(service);
  const selected = Number.isInteger(idx) ? services[idx] : undefined;
  const suggested = selected?.contactIndex;
  const topic = selected ? serviceTitles[idx] : t.generalTopic;
  const text = encodeURIComponent(t.greeting.replace('{service}', topic));

  const order = contacts.map((_, i) => i).sort((a, b) => Number(b === suggested) - Number(a === suggested));

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);

  return (
    <div className={'wa' + (open ? ' open' : '')}>
      <div className="wa-panel" id="wa-panel" role="dialog" aria-label={t.title} hidden={!open}>
        <div className="wa-head">
          <span className="wa-avatar"><WhatsAppIcon /></span>
          <div>
            <strong>{t.title}</strong>
            <small>{t.subtitle}</small>
          </div>
          <button type="button" className="wa-x" onClick={() => setOpen(false)} aria-label={t.close}>✕</button>
        </div>
        <ul className="wa-list">
          {order.map((i) => (
            <li key={i}>
              <a href={`https://wa.me/${whatsappNumber(contacts[i].phone)}?text=${text}`} target="_blank" rel="noopener noreferrer" className={i === suggested ? 'suggested' : undefined}>
                <span className="wa-dot" aria-hidden="true"></span>
                <span className="wa-who">
                  <strong>{departments[i]}</strong>
                  <small>{contacts[i].name}</small>
                  {i === suggested && <em>{t.suggested} {serviceTitles[idx]}</em>}
                </span>
                <span className="wa-go" aria-hidden="true">›</span>
              </a>
            </li>
          ))}
        </ul>
      </div>
      <button type="button" className="wa-fab" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-controls="wa-panel" aria-label={open ? t.close : t.open}>
        {open ? <span className="wa-close" aria-hidden="true">✕</span> : <WhatsAppIcon />}
      </button>
    </div>
  );
}
