import { industryMatrix } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';
import SectionHead from './SectionHead';

// Services × industries table showing core and supporting capabilities.
export default function CapabilityMatrix({ t }: { t: Dictionary }) {
  const m = t.pages.industries.matrix;
  const mark = (v: number) =>
    v === 2 ? <span className="dot core" title={m.core}></span> : v === 1 ? <span className="dot support" title={m.supporting}></span> : <span className="dot none"></span>;

  return (
    <section className="matrix section">
      <SectionHead eyebrow={m.eyebrow} h2a={m.h2a} h2Em={m.h2Em} lead={m.lead} />
      <div className="matrix-scroll" data-reveal>
        <table>
          <thead>
            <tr>
              <th scope="col">{m.service}</th>
              {t.industries.items.map((ind) => <th scope="col" key={ind.title}>{ind.title}</th>)}
            </tr>
          </thead>
          <tbody>
            {t.services.items.map((s, r) => (
              <tr key={s.title}>
                <th scope="row"><span>{String(r + 1).padStart(2, '0')}</span>{s.title}</th>
                {industryMatrix[r].map((v, c) => (
                  <td key={c}>
                    {mark(v)}
                    <span className="sr-only">{v === 2 ? m.core : v === 1 ? m.supporting : '—'}</span>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="matrix-legend">
        <span><span className="dot core"></span>{m.core}</span>
        <span><span className="dot support"></span>{m.supporting}</span>
      </div>
    </section>
  );
}
