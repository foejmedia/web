type Item = { title: string; p: string; label?: string };

type Props = {
  items: Item[];
  icons?: string[];
  tone?: 'light' | 'dark';
  columns?: 2 | 3 | 4;
  numbered?: boolean;
};

// Generic grid of feature cards: values, benefits, principles, team areas, mission/vision.
export default function CardGrid({ items, icons, tone = 'light', columns = 3, numbered = false }: Props) {
  return (
    <div className={`card-grid card-grid-${tone} cols-${columns}`}>
      {items.map((item, i) => (
        <article className="feature-card" key={item.title} data-reveal data-d={String((i % columns) + 1)}>
          <div className="feature-card-top">
            {icons?.[i] ? (
              <span className="feature-icon" aria-hidden="true">
                <svg viewBox="0 0 32 32"><path d={icons[i]} /></svg>
              </span>
            ) : (
              item.label && <span className="feature-label">{item.label}</span>
            )}
            {numbered && <span className="feature-num">{String(i + 1).padStart(2, '0')}</span>}
          </div>
          <h3>{item.title}</h3>
          <p>{item.p}</p>
        </article>
      ))}
    </div>
  );
}
