import type { Dictionary } from '@/lib/dictionaries';
import SectionHead from './SectionHead';

// Equipment categories with their representative units.
export default function CatalogueGrid({ t }: { t: Dictionary['pages']['fleet']['catalogue'] }) {
  return (
    <section className="catalogue section">
      <SectionHead eyebrow={t.eyebrow} h2a={t.h2a} h2Em={t.h2Em} lead={t.lead} />
      <div className="catalogue-grid">
        {t.items.map((cat, i) => (
          <article key={cat.title} data-reveal data-d={String(i + 1)}>
            <header>
              <span>{String(i + 1).padStart(2, '0')}</span>
              <h3>{cat.title}</h3>
            </header>
            <ul>
              {cat.list.map((item) => <li key={item}>{item}</li>)}
            </ul>
          </article>
        ))}
      </div>
    </section>
  );
}
