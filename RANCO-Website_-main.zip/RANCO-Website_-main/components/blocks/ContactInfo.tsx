import { contacts, GENERAL_CONTACT_INDEX, whatsappNumber } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';

const icons = {
  mail: 'M4 8h24v16H4zM4 8l12 9 12-9',
  clock: 'M16 4a12 12 0 100 24 12 12 0 000-24zM16 9v7l5 3',
  pin: 'M16 29s-9-8-9-15a9 9 0 0118 0c0 7-9 15-9 15zM16 17a3 3 0 100-6 3 3 0 000 6z',
  chat: 'M6 6h20v15H13l-7 5z',
};

// Quick-contact cards shown at the top of the contact page.
export default function ContactInfo({ t }: { t: Dictionary }) {
  const i = t.pages.contact.info;
  const general = contacts[GENERAL_CONTACT_INDEX];
  // PLACEHOLDER — confirm working hours and headquarters address with RANCO before launch.
  const cards = [
    { icon: icons.mail, label: i.email, value: 'info@ranco.com.sa', href: 'mailto:info@ranco.com.sa' },
    { icon: icons.chat, label: i.whatsapp, value: i.whatsappValue, href: `https://wa.me/${whatsappNumber(general.phone)}` },
    { icon: icons.clock, label: i.hours, value: i.hoursValue },
    { icon: icons.pin, label: i.location, value: i.locationValue },
  ];

  return (
    <section className="contact-info">
      {cards.map((c, n) => {
        const inner = (
          <>
            <span className="feature-icon" aria-hidden="true"><svg viewBox="0 0 32 32"><path d={c.icon} /></svg></span>
            <small>{c.label}</small>
            <strong>{c.value}</strong>
          </>
        );
        return c.href ? (
          <a key={c.label} href={c.href} data-reveal data-d={String(n + 1)} {...(c.href.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {})}>{inner}</a>
        ) : (
          <div key={c.label} data-reveal data-d={String(n + 1)}>{inner}</div>
        );
      })}
    </section>
  );
}
