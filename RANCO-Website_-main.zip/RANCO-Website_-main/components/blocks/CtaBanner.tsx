type Link = { label: string; href: string };
type Props = { eyebrow: string; h2a: string; h2Em: string; p: string; primary: Link; secondary?: Link; arrow: string; image?: string };

// Closing call-to-action over a dark photograph.
export default function CtaBanner({ eyebrow, h2a, h2Em, p, primary, secondary, arrow, image = '/assets/photos/cta-earth.jpg' }: Props) {
  return (
    <section className="cta-banner">
      <div className="cta-bg" style={{ backgroundImage: `radial-gradient(ellipse at center,#020814 0%,#020814b3 45%,#02081440 100%),url(${image})` }} aria-hidden="true"></div>
      <p className="eyebrow" data-reveal>{eyebrow}</p>
      <h2 data-reveal data-d="1">{h2a}<em>{h2Em}</em></h2>
      <p data-reveal data-d="2">{p}</p>
      <div className="actions" data-reveal data-d="3">
        <a className="button" href={primary.href}>{primary.label} <span>{arrow}</span></a>
        {secondary && <a className="hero-secondary" href={secondary.href}>{secondary.label} <span>{arrow}</span></a>}
      </div>
    </section>
  );
}
