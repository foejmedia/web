import { dictionaries, type Locale } from '@/lib/dictionaries';
import { blurbKey, href, page, type PageSlug } from '@/lib/routes';
import SectionHead from './SectionHead';

// Cross-links to related pages, shown near the end of each inner page.
export default function ExploreNext({ lang, slugs }: { lang: Locale; slugs: PageSlug[] }) {
  const t = dictionaries[lang];
  const e = t.pages.explore;
  return (
    <section className="explore section">
      <SectionHead eyebrow={e.eyebrow} h2a={e.h2a} h2Em={e.h2Em} breakTitle={false} />
      <div className="explore-grid">
        {slugs.map((slug, i) => {
          const p = page(slug);
          return (
            <a className="explore-card" href={href(lang, slug)} key={slug} data-reveal data-d={String(i + 1)}>
              <span className="explore-img" style={{ backgroundImage: `url(${p.hero})` }} aria-hidden="true"></span>
              <span className="explore-body">
                <small>{String(i + 1).padStart(2, '0')}</small>
                <strong>{t.nav[p.nav]}</strong>
                <span>{t.pages.blurbs[blurbKey[slug]]}</span>
                <em>{e.go} {t.arrow}</em>
              </span>
            </a>
          );
        })}
      </div>
    </section>
  );
}
