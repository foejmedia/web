import type { ReactNode } from 'react';

type Props = {
  image: string;
  eyebrow: string;
  h1a: string;
  h1Em: string;
  lead: string;
  home: { label: string; href: string };
  current: string;
  index: string;
  scroll: string;
  children?: ReactNode;
};

// Full-bleed, image-led hero used at the top of every inner page.
export default function PageHero({ image, eyebrow, h1a, h1Em, lead, home, current, index, scroll, children }: Props) {
  return (
    <>
    <section className="page-hero">
      <div className="page-hero-img" style={{ backgroundImage: `url(${image})` }} aria-hidden="true"></div>
      <div className="page-hero-lines" aria-hidden="true"></div>
      <div className="page-hero-inner">
        <div className="crumbs" role="navigation" aria-label="Breadcrumb">
          <a href={home.href}>{home.label}</a>
          <span aria-hidden="true">/</span>
          <span aria-current="page">{current}</span>
        </div>
        <p className="eyebrow"><span className="live-dot"></span> {eyebrow}</p>
        <h1>
          <span className="line"><span>{h1a}</span></span>
          <span className="line"><span><em>{h1Em}</em></span></span>
        </h1>
        <p className="lead">{lead}</p>
        {children && <div className="actions">{children}</div>}
      </div>
      <div className="page-hero-meta">
        <span className="page-index">{index}</span>
        <a href="#content" className="scroll-cue">{scroll} <span>↓</span></a>
      </div>
    </section>
    <span id="content" className="content-anchor" aria-hidden="true"></span>
    </>
  );
}
