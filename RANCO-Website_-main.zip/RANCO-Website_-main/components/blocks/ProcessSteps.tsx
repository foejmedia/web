import SectionHead from './SectionHead';

type Props = {
  eyebrow: string;
  h2a: string;
  h2Em: string;
  steps: { title: string; p: string }[];
  tone?: 'light' | 'dark';
  id?: string;
};

// Numbered, connected timeline for engagement, readiness and hiring processes.
export default function ProcessSteps({ eyebrow, h2a, h2Em, steps, tone = 'light', id }: Props) {
  return (
    <section className={`process section process-${tone}`} id={id}>
      <SectionHead eyebrow={eyebrow} h2a={h2a} h2Em={h2Em} />
      <ol className="process-track" style={{ ['--n' as string]: steps.length }}>
        {steps.map((s, i) => (
          <li key={s.title} data-reveal data-d={String(i + 1)}>
            <span className="process-dot">{String(i + 1).padStart(2, '0')}</span>
            <h3>{s.title}</h3>
            <p>{s.p}</p>
          </li>
        ))}
      </ol>
    </section>
  );
}
