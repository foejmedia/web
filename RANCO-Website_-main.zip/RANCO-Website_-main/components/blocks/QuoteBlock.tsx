type Props = { eyebrow: string; quote: string; body?: string; name: string; role: string; image: string };

// Full-bleed quotation over a darkened photograph.
export default function QuoteBlock({ eyebrow, quote, body, name, role, image }: Props) {
  return (
    <section className="quote-block">
      <div className="quote-bg" style={{ backgroundImage: `url(${image})` }} aria-hidden="true"></div>
      <div className="quote-inner">
        <p className="eyebrow" data-reveal>{eyebrow}</p>
        <span className="quote-mark" aria-hidden="true">“</span>
        <blockquote data-reveal data-d="1">{quote}</blockquote>
        {body && <p className="quote-body" data-reveal data-d="2">{body}</p>}
        <div className="quote-cite" data-reveal data-d="3">
          <strong>{name}</strong>
          <span>{role}</span>
        </div>
      </div>
    </section>
  );
}
