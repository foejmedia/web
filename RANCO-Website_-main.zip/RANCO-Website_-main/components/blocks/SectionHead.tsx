type Props = {
  eyebrow: string;
  h2a: string;
  h2Em: string;
  lead?: string;
  link?: { label: string; href: string; arrow: string };
  breakTitle?: boolean;
};

// Standard section heading: eyebrow, two-tone title, optional lead and "view all" link.
export default function SectionHead({ eyebrow, h2a, h2Em, lead, link, breakTitle = true }: Props) {
  return (
    <div className="section-head">
      <div>
        <p className="eyebrow" data-reveal>{eyebrow}</p>
        <h2 data-reveal data-d="1">{h2a}{breakTitle && <br />}<em>{h2Em}</em></h2>
      </div>
      {(lead || link) && (
        <div className="section-head-side" data-reveal data-d="2">
          {lead && <p>{lead}</p>}
          {link && <a className="textlink" href={link.href}>{link.label} {link.arrow}</a>}
        </div>
      )}
    </div>
  );
}
