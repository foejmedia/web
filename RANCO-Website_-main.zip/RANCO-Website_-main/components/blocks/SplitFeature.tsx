import type { ReactNode } from 'react';

type Props = {
  image: string;
  index: string;
  title: string;
  teaser?: string;
  body: string;
  points?: string[];
  reverse?: boolean;
  id?: string;
  children?: ReactNode;
};

// Alternating image + text row for in-depth content (service details, commitments).
export default function SplitFeature({ image, index, title, teaser, body, points, reverse = false, id, children }: Props) {
  return (
    <article className={`split${reverse ? ' split-reverse' : ''}`} id={id}>
      <div className="split-media" data-reveal="zoom">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={image} alt="" loading="lazy" />
        <span className="split-index">{index}</span>
      </div>
      <div className="split-copy" data-reveal={reverse ? 'left' : 'right'} data-d="1">
        {teaser && <p className="eyebrow">{teaser}</p>}
        <h3>{title}</h3>
        <p>{body}</p>
        {points && (
          <ul className="split-points">
            {points.map((pt) => <li key={pt}>{pt}</li>)}
          </ul>
        )}
        {children}
      </div>
    </article>
  );
}
