import type { Dictionary } from '@/lib/dictionaries';
import SectionHead from './SectionHead';

// Large ISO management-system cards.
export default function StandardsShowcase({ t }: { t: Dictionary }) {
  const s = t.pages.qhse.standards;
  return (
    <section className="standards-show section">
      <SectionHead eyebrow={s.eyebrow} h2a={s.h2a} h2Em={s.h2Em} />
      <div className="standards-grid">
        {t.qhse.standards.map((std, i) => {
          const [name, year] = std.code.split(':');
          return (
            <article key={std.code} data-reveal="zoom" data-d={String(i + 1)}>
              <span className="std-ring" aria-hidden="true"></span>
              <small>{name.replace(/\d+/, '').trim()}</small>
              <strong dir="ltr">{name.replace(/\D+/, '')}</strong>
              <span className="std-year" dir="ltr">:{year}</span>
              <p>{std.label}</p>
            </article>
          );
        })}
      </div>
    </section>
  );
}
