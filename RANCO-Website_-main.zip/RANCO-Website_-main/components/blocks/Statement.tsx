type Props = { eyebrow: string; text: string; p?: string; image?: string; id?: string };

// Large editorial statement, optionally paired with an image.
export default function Statement({ eyebrow, text, p, image, id }: Props) {
  return (
    <section className={`statement section${image ? ' has-image' : ''}`} id={id}>
      <div>
        <p className="eyebrow" data-reveal>{eyebrow}</p>
        <p className="statement-text" data-reveal data-d="1">{text}</p>
        {p && <p className="statement-p" data-reveal data-d="2">{p}</p>}
      </div>
      {image && (
        <div className="statement-media" data-reveal="zoom" data-d="2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={image} alt="" loading="lazy" />
        </div>
      )}
    </section>
  );
}
