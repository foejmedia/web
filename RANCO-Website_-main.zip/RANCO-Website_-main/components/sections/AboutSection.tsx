import CountUp from '@/components/CountUp';
import type { Dictionary } from '@/lib/dictionaries';

type Props = { t: Dictionary; more?: { label: string; href: string } };

export default function AboutSection({ t, more }: Props) {
  return (
    <section className="about section" id="about">
      <div className="about-heading">
        <p className="eyebrow" data-reveal>{t.about.eyebrow}</p>
        <h2 data-reveal data-d="1">{t.about.h2a}<br />{t.about.h2b}<em>{t.about.h2Em}</em></h2>
        <div className="about-visual" data-reveal="zoom" data-d="2">
          <div className="visual-lines"></div>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img className="logo-on-dark" src="/assets/ranco-logo-dark.png" alt="RANCO" />
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img className="logo-on-light" src="/assets/ranco-logo-light.png" alt="" aria-hidden="true" />
          <span>{t.about.visual[0]}<br />{t.about.visual[1]}</span>
        </div>
      </div>
      <div>
        <p className="intro" data-reveal="right">{t.about.intro}</p>
        <p data-reveal="right" data-d="1">{t.about.body}</p>
        <div className="facts" data-reveal data-d="2">
          <div><strong><CountUp to={22} /><span>+</span></strong><small>{t.about.fact1[0]}<br />{t.about.fact1[1]}</small></div>
          <div><strong><CountUp to={360} duration={2000} /><span>°</span></strong><small>{t.about.fact2[0]}<br />{t.about.fact2[1]}</small></div>
        </div>
        {more ? (
          <a className="textlink" href={more.href} data-reveal data-d="3">{more.label} {t.arrow}</a>
        ) : (
          <details data-reveal data-d="3">
            <summary>{t.about.chairmanSummary} <span>+</span></summary>
            <p>{t.about.quote}</p>
            <p>{t.about.body2}</p>
            <strong>{t.about.chairmanName}</strong>
            <p>{t.about.chairmanTitle}</p>
          </details>
        )}
      </div>
    </section>
  );
}
