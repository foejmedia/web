import type { Dictionary } from '@/lib/dictionaries';

type Props = { t: Dictionary; more?: { label: string; href: string }; id?: string };

export default function CareersSection({ t, more, id = 'careers' }: Props) {
  const c = t.careers;
  return (
    <section className="careers section" id={id}>
      <p className="eyebrow" data-reveal>{c.eyebrow}</p>
      <h2 data-reveal data-d="1">{c.h2a}<br /><em>{c.h2Em}</em></h2>
      <div data-reveal data-d="2">
        <p>{c.p}</p>
        <a className="textlink" href={more ? more.href : `mailto:info@ranco.com.sa?subject=${encodeURIComponent(c.mailSubject)}`}>{more ? more.label : c.link} {t.arrow}</a>
        <small>{c.small}</small>
        <ul className="career-roles">
          {c.roles.map((r) => <li key={r}>{r}</li>)}
        </ul>
      </div>
    </section>
  );
}
