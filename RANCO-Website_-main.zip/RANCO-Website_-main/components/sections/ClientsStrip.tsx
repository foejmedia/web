import { clients } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';

export default function ClientsStrip({ t }: { t: Dictionary }) {
  return (
    <section className="clients" aria-label={t.clients.label}>
      <p className="clients-label" data-reveal>{t.clients.label}</p>
      <div className="clients-track" data-reveal data-d="1">
        <div className="clients-row">
          {[...clients, ...clients].map((c, i) => (
            <span className="client" key={i} aria-hidden={i >= clients.length ? true : undefined}>
              {c.logo ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={c.logo} alt={c.name} />
              ) : (
                c.name
              )}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
