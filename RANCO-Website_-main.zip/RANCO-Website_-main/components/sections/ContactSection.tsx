import SectionHead from '@/components/blocks/SectionHead';
import InquiryForm from '@/components/InquiryForm';
import { contacts } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';

export default function ContactSection({ t }: { t: Dictionary }) {
  const c = t.contact;
  return (
    <section className="contact section" id="contact">
      <SectionHead eyebrow={c.eyebrow} h2a={c.h2a} h2Em={`${c.h2b}${c.h2Em}`} lead={c.lead} />
      <div className="contact-layout">
        <div id="contacts">
          {contacts.map((p, i) => (
            <article className="person" key={p.email + i} data-reveal="left" data-d={String((i % 5) + 1)}>
              <h3>{c.departments[i]}</h3>
              <p>{p.name}</p>
              <a href={`tel:${p.phone.replaceAll(' ', '')}`} dir="ltr">{p.phone}</a>
              <a href={`mailto:${p.email}`}>{p.email} {t.arrow}</a>
            </article>
          ))}
        </div>
        <InquiryForm t={t.form} serviceTitles={t.services.items.map((s) => s.title)} arrow={t.arrow} />
      </div>
    </section>
  );
}
