import SectionHead from '@/components/blocks/SectionHead';
import CoverageMap from '@/components/CoverageMap';
import type { Dictionary } from '@/lib/dictionaries';

export default function CoverageSection({ t }: { t: Dictionary }) {
  return (
    <section className="coverage section" id="coverage">
      <SectionHead eyebrow={t.map.eyebrow} h2a={t.map.h2a} h2Em={t.map.h2Em} lead={t.map.lead} />
      <CoverageMap t={t.map} />
    </section>
  );
}
