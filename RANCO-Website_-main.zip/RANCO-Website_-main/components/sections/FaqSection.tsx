import type { Dictionary } from '@/lib/dictionaries';

type Props = { t: Dictionary; items?: { q: string; a: string }[]; more?: { label: string; href: string }; id?: string };

export default function FaqSection({ t, items = t.faq.items, more, id = 'faq' }: Props) {
  const f = t.faq;
  return (
    <section className="faq section" id={id}>
      <div className="faq-head">
        <p className="eyebrow" data-reveal>{f.eyebrow}</p>
        <h2 data-reveal data-d="1">{f.h2a}<em>{f.h2Em}</em></h2>
        <p data-reveal data-d="2">{f.lead}</p>
        {more && <a className="textlink" href={more.href} data-reveal data-d="3">{more.label} {t.arrow}</a>}
      </div>
      <div className="faq-list">
        {items.map((item, i) => (
          <details key={item.q} data-reveal data-d={String((i % 3) + 1)}>
            <summary><span className="faq-n">{String(i + 1).padStart(2, '0')}</span>{item.q}<span className="faq-plus" aria-hidden="true">+</span></summary>
            <p>{item.a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
