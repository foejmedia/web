import SectionHead from '@/components/blocks/SectionHead';
import { fleetImages } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';

type Props = { t: Dictionary; more?: { label: string; href: string }; id?: string };

export default function FleetSection({ t, more, id = 'fleet' }: Props) {
  const s = t.fleet;
  return (
    <section className="fleet section" id={id}>
      <SectionHead eyebrow={s.eyebrow} h2a={s.h2a} h2Em={s.h2Em} lead={s.lead} link={more && { ...more, arrow: t.arrow }} />
      <div className="fleet-grid">
        {s.items.map((item, i) => (
          <figure className="fleet-tile" key={item.title} data-reveal data-d={String((i % 3) + 1)}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={fleetImages[i]} alt="" loading="lazy" />
            <figcaption>
              <small>{item.tag}</small>
              <strong>{item.title}</strong>
            </figcaption>
          </figure>
        ))}
      </div>
      <p className="fleet-note">{s.note}</p>
    </section>
  );
}
