import SectionHead from '@/components/blocks/SectionHead';
import { industryImages } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';

type Props = { t: Dictionary; more?: { label: string; href: string }; id?: string };

export default function IndustriesSection({ t, more, id = 'industries' }: Props) {
  const s = t.industries;
  return (
    <section className="industries section" id={id}>
      <SectionHead eyebrow={s.eyebrow} h2a={s.h2a} h2Em={s.h2Em} lead={s.lead} link={more && { ...more, arrow: t.arrow }} />
      <div className="industry-grid">
        {s.items.map((item, i) => (
          <article className="industry-card" key={item.title} data-reveal="zoom" data-d={String((i % 3) + 1)}>
            <div className="industry-img" style={{ backgroundImage: `url(${industryImages[i]})` }} aria-hidden="true"></div>
            <span className="industry-num">0{i + 1}</span>
            <div className="industry-body">
              <h3>{item.title}</h3>
              <p>{item.p}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
