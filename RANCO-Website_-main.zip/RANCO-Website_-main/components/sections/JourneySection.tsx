import type { Dictionary } from '@/lib/dictionaries';

export default function JourneySection({ t }: { t: Dictionary }) {
  return (
    <section className="journey section">
      <div>
        <p className="eyebrow" data-reveal>{t.journey.eyebrow}</p>
        <h2 data-reveal data-d="1">{t.journey.h2[0]}<br />{t.journey.h2[1]}</h2>
      </div>
      <div className="journey-steps">
        {t.journey.steps.map((s, i) => (
          <article key={s.label} data-reveal data-d={String(i + 1)}>
            <span>{s.label}</span>
            <h3>{s.h3[0]}<br />{s.h3[1]}</h3>
            <p>{s.p}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
