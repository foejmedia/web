import type { Dictionary } from '@/lib/dictionaries';

type Props = { t: Dictionary; more?: { label: string; href: string }; id?: string };

export default function QhseSection({ t, more, id = 'qhse' }: Props) {
  const q = t.qhse;
  return (
    <section className="qhse section" id={id}>
      <div>
        <p className="eyebrow" data-reveal>{q.eyebrow}</p>
        <h2 data-reveal data-d="1">{q.h2[0]}<br />{q.h2[1]}<br /><em>{q.h2Em}</em></h2>
        <p data-reveal data-d="2">{q.p}</p>
        <div className="goal" data-reveal data-d="3">{q.goalLabel} <strong>{q.goal[0]}<br />{q.goal[1]}</strong></div>
        {more && <a className="textlink light" href={more.href} data-reveal data-d="4">{more.label} {t.arrow}</a>}
      </div>
      <div className="qhse-list">
        {q.items.map((item, i) => (
          <article key={item.h3} data-reveal="right" data-d={String(i + 1)}>
            <span>0{i + 1}</span>
            <div><h3>{item.h3}</h3><p>{item.p}</p></div>
          </article>
        ))}
        <div className="standards">
          {q.standards.map((s, i) => (
            <span key={s.code} data-reveal="zoom" data-d={String(i + 3)}>{s.code}<small>{s.label}</small></span>
          ))}
        </div>
      </div>
    </section>
  );
}
