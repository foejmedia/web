import SectionHead from '@/components/blocks/SectionHead';
import ServiceList from '@/components/ServiceList';
import type { Dictionary } from '@/lib/dictionaries';

type Props = { t: Dictionary; more?: { label: string; href: string }; footerHref: string; id?: string };

export default function ServicesSection({ t, more, footerHref, id = 'services' }: Props) {
  const s = t.services;
  return (
    <section className="services section" id={id}>
      <SectionHead eyebrow={s.eyebrow} h2a={s.h2[0]} h2Em={s.h2[1]} lead={s.lead} link={more && { ...more, arrow: t.arrow }} />
      <ServiceList t={s} arrow={t.arrow} />
      <div className="service-footer" data-reveal>
        <span>{s.footer}</span>
        <a className="textlink" href={footerHref}>{s.footerLink} {t.arrow}</a>
      </div>
    </section>
  );
}
