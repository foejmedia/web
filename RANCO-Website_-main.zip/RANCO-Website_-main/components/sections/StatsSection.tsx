import CountUp from '@/components/CountUp';
import { stats } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';

export default function StatsSection({ t }: { t: Dictionary }) {
  return (
    <section className="stats section" id="safety">
      <div className="stats-head">
        <p className="eyebrow" data-reveal>{t.stats.eyebrow}</p>
        <h2 data-reveal data-d="1">{t.stats.h2a}<em>{t.stats.h2Em}</em></h2>
      </div>
      <div className="stats-grid">
        {stats.map((s, i) => (
          <div className="stat" key={i} data-reveal data-d={String(i + 1)}>
            <strong>
              <CountUp to={s.value} separate duration={2200} />
              <span>{t.stats.items[i].suffix}</span>
            </strong>
            <p>{t.stats.items[i].label}</p>
            <span className="stat-bar" aria-hidden="true"></span>
          </div>
        ))}
      </div>
    </section>
  );
}
