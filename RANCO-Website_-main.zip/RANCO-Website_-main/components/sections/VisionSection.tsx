import type { Dictionary } from '@/lib/dictionaries';

type Props = { t: Dictionary; more?: { label: string; href: string }; id?: string };

export default function VisionSection({ t, more, id = 'vision' }: Props) {
  const v = t.vision;
  return (
    <section className="vision section" id={id}>
      <div className="vision-bg" aria-hidden="true"></div>
      <div className="vision-copy">
        <p className="eyebrow" data-reveal>{v.eyebrow}</p>
        <h2 data-reveal data-d="1">{v.h2a}<br /><em>{v.h2Em}</em></h2>
        <p data-reveal data-d="2">{v.p}</p>
        {more && <a className="textlink light" href={more.href} data-reveal data-d="3">{more.label} {t.arrow}</a>}
      </div>
      <div className="vision-pillars">
        {v.pillars.map((pillar, i) => (
          <article key={pillar.title} data-reveal data-d={String(i + 1)}>
            <span>0{i + 1}</span>
            <h3>{pillar.title}</h3>
            <p>{pillar.p}</p>
          </article>
        ))}
      </div>
      <span className="vision-mark" aria-hidden="true">2030</span>
    </section>
  );
}
