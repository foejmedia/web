import { whyIcons } from '@/lib/data';
import type { Dictionary } from '@/lib/dictionaries';

export default function WhySection({ t }: { t: Dictionary }) {
  return (
    <section className="why section" id="why">
      <div className="why-bg" aria-hidden="true"></div>
      <div className="why-head">
        <p className="eyebrow" data-reveal>{t.why.eyebrow}</p>
        <h2 data-reveal data-d="1">{t.why.h2a}<em>{t.why.h2Em}</em></h2>
        <p data-reveal data-d="2">{t.why.lead}</p>
      </div>
      <div className="why-grid">
        {t.why.items.map((item, i) => (
          <article key={item.title} data-reveal data-d={String((i % 3) + 1)}>
            <span className="why-icon" aria-hidden="true">
              <svg viewBox="0 0 32 32"><path d={whyIcons[i]} /></svg>
            </span>
            <h3>{item.title}</h3>
            <p>{item.p}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
