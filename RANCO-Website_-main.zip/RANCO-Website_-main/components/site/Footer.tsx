import { contacts, GENERAL_CONTACT_INDEX } from '@/lib/data';
import { dictionaries, type Locale } from '@/lib/dictionaries';
import { href, type PageSlug } from '@/lib/routes';

const companyLinks: PageSlug[] = ['about', 'vision-2030', 'qhse', 'careers'];
const capabilityLinks: PageSlug[] = ['services', 'industries', 'fleet', 'faq'];

export default function Footer({ lang }: { lang: Locale }) {
  const t = dictionaries[lang];
  const f = t.footer;
  const label = (slug: PageSlug) => t.nav[slug === 'vision-2030' ? 'vision' : slug];
  const phone = contacts[GENERAL_CONTACT_INDEX].phone;

  return (
    <footer className="site-footer">
      <div className="footer-cta" data-reveal>
        <p>{f.tagline[0]} <em>{f.tagline[1]}</em></p>
        <a className="button" href={href(lang, 'contact', 'inquiry')}>{f.cta} <span>{t.arrow}</span></a>
      </div>

      <div className="footer-grid">
        <div className="footer-about">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/assets/ranco-logo-dark.png" alt="RANCO" />
          <p>{f.lead}</p>
          <div className="footer-iso">
            {t.qhse.standards.map((s) => <span key={s.code}>{s.code}</span>)}
          </div>
        </div>
        <div className="footer-links" role="navigation" aria-label={f.cols.company}>
          <h3>{f.cols.company}</h3>
          {companyLinks.map((s) => <a key={s} href={href(lang, s)}>{label(s)}</a>)}
        </div>
        <div className="footer-links" role="navigation" aria-label={f.cols.capabilities}>
          <h3>{f.cols.capabilities}</h3>
          {capabilityLinks.map((s) => <a key={s} href={href(lang, s)}>{label(s)}</a>)}
          <a href={`/${lang}/oil-gas-prices`}>{t.nav.oilPrices}</a>
        </div>
        <div>
          <h3>{f.cols.contact}</h3>
          <a href="mailto:info@ranco.com.sa">info@ranco.com.sa</a>
          <a href={`tel:${phone.replaceAll(' ', '')}`} dir="ltr">{phone}</a>
          <p>{f.address}</p>
          <a className="footer-contact-link" href={href(lang, 'contact')}>{t.nav.contact} {t.arrow}</a>
        </div>
      </div>

      <div className="footer-mark" aria-hidden="true">RANCO</div>

      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} {f.rights}</p>
        <small>{f.small}</small>
        <a href="#main">{f.back}</a>
      </div>
    </footer>
  );
}
