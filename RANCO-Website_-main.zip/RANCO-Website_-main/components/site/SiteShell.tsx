import type { ReactNode } from 'react';
import Header from '@/components/Header';
import { InquiryProvider } from '@/components/InquiryProvider';
import ScrollProgress from '@/components/ScrollProgress';
import ScrollReveal from '@/components/ScrollReveal';
import WhatsAppWidget from '@/components/WhatsAppWidget';
import { dictionaries, type Locale } from '@/lib/dictionaries';
import { href } from '@/lib/routes';
import Footer from './Footer';

type Props = {
  lang: Locale;
  children: ReactNode;
  // True when this page renders the inquiry form itself; otherwise inquiry links go to the contact page.
  formOnPage?: boolean;
  mainClassName?: string;
};

// Chrome shared by every page: utility bar, header, footer, scroll progress and WhatsApp widget.
export default function SiteShell({ lang, children, formOnPage = false, mainClassName }: Props) {
  const t = dictionaries[lang];
  const serviceTitles = t.services.items.map((s) => s.title);

  return (
    <InquiryProvider formPath={formOnPage ? '' : href(lang, 'contact')}>
      <ScrollReveal />
      <a className="skip" href="#main">{t.skip}</a>
      <div className="utility">
        <span>{t.utility}</span>
        <a href="mailto:info@ranco.com.sa">info@ranco.com.sa {t.arrow}</a>
      </div>
      <Header lang={lang} nav={t.nav} blurbs={t.pages.blurbs} arrow={t.arrow} switchLabel={t.switchLabel} switchAria={t.switchAria} themeLabels={t.theme} />
      <main id="main" className={mainClassName}>{children}</main>
      <Footer lang={lang} />
      <ScrollProgress />
      <WhatsAppWidget t={t.whatsapp} departments={t.contact.departments} serviceTitles={serviceTitles} />
    </InquiryProvider>
  );
}
