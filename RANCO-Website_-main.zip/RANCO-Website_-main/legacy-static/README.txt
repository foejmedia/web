RANCO WEBSITE

Extract this ZIP and open index.html in your browser.
Upload index.html, style.css, app.js and the assets folder to any static web host.
Keep the folder structure intact.

The inquiry form opens the visitor's email application; no server is required.
The industrial hero image is AI-generated conceptual imagery.
