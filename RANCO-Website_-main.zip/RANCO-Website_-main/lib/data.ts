// Language-neutral data. All visible text lives in lib/dictionaries.ts, aligned by index.

export type Service = { contactIndex: number; icon: string };
export type Contact = { name: string; phone: string; email: string };
export type RigMoveStep = { image: string; position: string; zoom: number };
export type Location = { id: string; lon: number; lat: number; region: 'east' | 'central' | 'west'; hub?: boolean };
export type Stat = { value: number; pad?: number };
export type Client = { name: string; logo?: string };

export const services: Service[] = [
  { contactIndex: 1, icon: 'M5 27V10l11-5 11 5v17M11 27V16h10v11M11 11h.01M21 11h.01M16 9h.01M2 27h28' },
  { contactIndex: 0, icon: 'M3 23h26M7 23V11h9v12M16 17h6l5 6M10 11V6h9M19 6l6 8' },
  { contactIndex: 0, icon: 'M10 28L15 4h3l5 24M12 19h9M14 12h5M7 28h20M15 4h11v13M24 17h4' },
  { contactIndex: 0, icon: 'M3 8h17v16H3zM20 14h5l5 6v4H20' },
  { contactIndex: 1, icon: 'M3 27h26M6 27V13h9v14M15 27V5h11v22M19 10h3M19 16h3M19 22h3M9 18h3' },
  { contactIndex: 2, icon: 'M18 3L8 18h8l-2 11 10-16h-8z' },
  { contactIndex: 3, icon: 'M3 10h12v12h14M3 7v6M12 7h6v6M12 19h6v6M27 19v6M6 7v6M23 19v6' },
  { contactIndex: 4, icon: 'M12 11l-4 4 4 4M20 11l4 4-4 4M11 29h10M16 24v5' },
];

export const RIG_MOVE_SERVICE_INDEX = 2;
export const GENERAL_CONTACT_INDEX = 3;

export const contacts: Contact[] = [
  { name: 'Shakeel', phone: '+966 55 597 8341', email: 'shakeel@ranco.com.sa' },
  { name: 'Mathan Kumar', phone: '+966 53 128 3496', email: 'eng.kumar@ranco.com.sa' },
  { name: 'Josiah P. Ambrose', phone: '+966 55 969 3063', email: 'josiah@ranco.com.sa' },
  { name: 'Imran Pasha', phone: '+966 57 949 7747', email: 'imran@ranco.com.sa' },
  { name: 'Umar Farooq', phone: '+966 57 979 1674', email: 'info@ranco.com.sa' },
];

// Photos from Pexels (free licence), stored in public/assets/rig/. Replace any file to change a phase's image.
export const rigMoveSteps: RigMoveStep[] = [
  { image: '/assets/rig/survey.jpg', position: '50% 50%', zoom: 1.08 },
  { image: '/assets/rig/rig-down.jpg', position: '45% 50%', zoom: 1.08 },
  { image: '/assets/rig/load-out.jpg', position: '40% 50%', zoom: 1.08 },
  { image: '/assets/rig/convoy.jpg', position: '50% 55%', zoom: 1.08 },
  { image: '/assets/rig/rig-up.jpg', position: '50% 55%', zoom: 1.08 },
];

// PLACEHOLDER — confirm RANCO's real operating locations before launch.
export const locations: Location[] = [
  { id: 'dammam', lon: 50.1, lat: 26.43, region: 'east', hub: true },
  { id: 'jubail', lon: 49.66, lat: 27.01, region: 'east' },
  { id: 'rastanura', lon: 50.16, lat: 26.64, region: 'east' },
  { id: 'abqaiq', lon: 49.67, lat: 25.94, region: 'east' },
  { id: 'ahsa', lon: 49.59, lat: 25.38, region: 'east' },
  { id: 'hafar', lon: 45.96, lat: 28.43, region: 'east' },
  { id: 'shaybah', lon: 53.98, lat: 22.51, region: 'east' },
  { id: 'riyadh', lon: 46.68, lat: 24.71, region: 'central', hub: true },
  { id: 'khurais', lon: 48.2, lat: 25.07, region: 'central' },
  { id: 'jeddah', lon: 39.19, lat: 21.49, region: 'west', hub: true },
  { id: 'yanbu', lon: 38.06, lat: 24.09, region: 'west' },
];

// PLACEHOLDER figures — replace with RANCO's verified numbers before launch.
export const stats: Stat[] = [{ value: 2000000 }, { value: 350 }, { value: 120 }, { value: 0 }];

// PLACEHOLDER — add real client/partner logos (with permission) to public/assets/clients/ and set `logo`.
export const clients: Client[] = [
  { name: 'CLIENT ONE' },
  { name: 'PARTNER TWO' },
  { name: 'CLIENT THREE' },
  { name: 'PARTNER FOUR' },
  { name: 'CLIENT FIVE' },
  { name: 'PARTNER SIX' },
  { name: 'CLIENT SEVEN' },
  { name: 'PARTNER EIGHT' },
];

export const whatsappNumber = (phone: string) => phone.replace(/\D/g, '');

// Photography (Unsplash License), aligned by index with the matching dictionary lists.
export const industryImages = ['oil-gas', 'power', 'infrastructure', 'construction', 'industrial', 'technology'].map((n) => `/assets/photos/${n}.jpg`);
export const fleetImages = ['fleet-excavator', 'fleet-crane', 'fleet-logistics', 'fleet-pipeline', 'fleet-haulage', 'fleet-earthworks'].map((n) => `/assets/photos/${n}.jpg`);

export const whyIcons: string[] = [
  'M4 16h8M20 16h8M16 4v8M16 20v8M10 10l12 12M22 10L10 22',
  'M16 3l11 4v8c0 7-5 12-11 14C10 27 5 22 5 15V7zM11 16l4 4 7-8',
  'M16 29s-9-8-9-15a9 9 0 0118 0c0 7-9 15-9 15zM16 17a3 3 0 100-6 3 3 0 000 6z',
  'M3 18h8l3-8 4 16 3-8h8',
  'M4 26V14M11 26V8M18 26V17M25 26V5M2 29h28',
  'M8 17l5 5 11-11M4 16a12 12 0 1024 0 12 12 0 00-24 0',
];

// One photo per service, aligned with Dictionary['services']['items'].
export const serviceImages = [
  'construction', 'fleet-excavator', 'fleet-crane', 'fleet-haulage', 'infrastructure', 'industrial', 'fleet-pipeline', 'dashboard',
].map((n) => `/assets/photos/${n}.jpg`);

// Capability map: rows = services, columns = industries. 2 = core, 1 = supporting, 0 = not offered.
// PLACEHOLDER — confirm with RANCO before launch.
export const industryMatrix: number[][] = [
  [2, 2, 2, 2, 2, 1],
  [2, 2, 2, 2, 2, 0],
  [2, 0, 0, 0, 0, 0],
  [2, 2, 2, 2, 2, 0],
  [1, 2, 2, 2, 1, 0],
  [2, 2, 1, 2, 2, 0],
  [2, 1, 1, 0, 2, 0],
  [2, 1, 1, 1, 1, 2],
];

export const valueIcons: string[] = [
  'M16 3l11 4v8c0 7-5 12-11 14C10 27 5 22 5 15V7zM11 16l4 4 7-8',
  'M16 4v24M6 10h20M9 10l-4 9h8zM23 10l-4 9h8z',
  'M16 3l3.8 7.8 8.2 1.2-6 5.8 1.4 8.2-7.4-3.9-7.4 3.9 1.4-8.2-6-5.8 8.2-1.2z',
  'M4 17l6-6 5 4 6-6 7 7M4 17l8 8 4-3 4 3 8-8',
  'M16 4a8 8 0 00-5 14v4h10v-4a8 8 0 00-5-14zM12 26h8M14 29h4',
  'M16 29s-9-8-9-15a9 9 0 0118 0c0 7-9 15-9 15zM16 17a3 3 0 100-6 3 3 0 000 6z',
];

// Photos for the 3D sphere gallery on the home page (repeated to fill the sphere).
export const sphereImages = [
  '/assets/rig/rig-up.jpg', '/assets/photos/fleet-crane.jpg', '/assets/photos/oil-gas.jpg', '/assets/rig/convoy.jpg',
  '/assets/photos/fleet-excavator.jpg', '/assets/photos/construction.jpg', '/assets/rig/load-out.jpg', '/assets/photos/fleet-haulage.jpg',
  '/assets/photos/industrial.jpg', '/assets/photos/infrastructure.jpg', '/assets/rig/rig-down.jpg', '/assets/photos/fleet-pipeline.jpg',
  '/assets/photos/engineers.jpg', '/assets/rig/survey.jpg', '/assets/photos/power.jpg', '/assets/photos/fleet-earthworks.jpg',
];
