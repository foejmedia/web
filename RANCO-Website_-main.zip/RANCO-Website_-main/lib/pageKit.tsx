import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import { notFound } from 'next/navigation';
import CtaBanner from '@/components/blocks/CtaBanner';
import PageHero from '@/components/blocks/PageHero';
import { contacts } from './data';
import { dictionaries, isLocale, locales, type Dictionary, type Locale } from './dictionaries';
import { href, page, pages, type PageSlug } from './routes';

type Params = { params: Promise<{ lang: string }> };

export const staticParams = () => locales.map((lang) => ({ lang }));

export async function resolvePage({ params }: Params): Promise<{ lang: Locale; t: Dictionary }> {
  const { lang } = await params;
  if (!isLocale(lang)) notFound();
  return { lang, t: dictionaries[lang] };
}

type HeroCopy = { eyebrow: string; h1a: string; h1Em: string; lead: string };

// Builds per-page <title>/<description> from the page's hero copy.
export const pageMetadata = (slug: PageSlug, pick: (t: Dictionary) => HeroCopy) =>
  async function generateMetadata({ params }: Params): Promise<Metadata> {
    const { lang } = await params;
    if (!isLocale(lang)) return {};
    const t = dictionaries[lang];
    const hero = pick(t);
    return {
      title: `${t.nav[page(slug).nav]} — RANCO`,
      description: hero.lead,
      alternates: { languages: { en: `/en/${slug}`, ar: `/ar/${slug}` } },
    };
  };

export function InnerHero({ lang, slug, hero, children }: { lang: Locale; slug: PageSlug; hero: HeroCopy; children?: ReactNode }) {
  const t = dictionaries[lang];
  const p = page(slug);
  const n = pages.findIndex((x) => x.slug === slug) + 1;
  return (
    <PageHero
      image={p.hero}
      {...hero}
      home={{ label: t.pages.home, href: href(lang) }}
      current={t.nav[p.nav]}
      index={`${String(n).padStart(2, '0')} / ${String(pages.length).padStart(2, '0')}`}
      scroll={t.pages.scroll}
    >
      {children}
    </PageHero>
  );
}

// Standard closing call-to-action for inner pages.
export function PageCta({ lang, image }: { lang: Locale; image?: string }) {
  const t = dictionaries[lang];
  return (
    <CtaBanner
      eyebrow={t.cta.eyebrow}
      h2a={t.cta.h2a}
      h2Em={t.cta.h2Em}
      p={t.cta.p}
      arrow={t.arrow}
      image={image}
      primary={{ label: t.cta.primary, href: href(lang, 'contact', 'inquiry') }}
      secondary={{ label: t.cta.secondary, href: `tel:${contacts[0].phone.replaceAll(' ', '')}` }}
    />
  );
}
