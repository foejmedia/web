import type { Dictionary, Locale } from './dictionaries';

// Every inner page of the site. `slug` is the URL segment under /[lang]/; `nav` is its label key in Dictionary['nav'].
export const pages = [
  { slug: 'about', nav: 'about', hero: '/assets/photos/about-hero.jpg' },
  { slug: 'services', nav: 'services', hero: '/assets/photos/construction.jpg' },
  { slug: 'industries', nav: 'industries', hero: '/assets/photos/oil-gas.jpg' },
  { slug: 'fleet', nav: 'fleet', hero: '/assets/photos/fleet-earthworks.jpg' },
  { slug: 'qhse', nav: 'qhse', hero: '/assets/photos/why-bg.jpg' },
  { slug: 'careers', nav: 'careers', hero: '/assets/photos/careers-bg.jpg' },
  { slug: 'contact', nav: 'contact', hero: '/assets/photos/contact-hero.jpg' },
  { slug: 'vision-2030', nav: 'vision', hero: '/assets/photos/vision-desert.jpg' },
  { slug: 'faq', nav: 'faq', hero: '/assets/photos/faq-hero.jpg' },
] as const satisfies readonly { slug: string; nav: keyof Dictionary['nav']; hero: string }[];

export type PageSlug = (typeof pages)[number]['slug'];

export const href = (lang: Locale, slug?: PageSlug | '', hash?: string) => `/${lang}${slug ? `/${slug}` : ''}${hash ? `#${hash}` : ''}`;

export const page = (slug: PageSlug) => pages.find((p) => p.slug === slug)!;

// Key in Dictionary['pages']['blurbs'] for each page.
export const blurbKey: Record<PageSlug, string> = {
  about: 'about', services: 'services', industries: 'industries', fleet: 'fleet', qhse: 'qhse',
  careers: 'careers', contact: 'contact', 'vision-2030': 'vision', faq: 'faq',
};
